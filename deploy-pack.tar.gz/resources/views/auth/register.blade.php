<!doctype html>
<html lang="pt-AO" class="dark">
<head>
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Criar Conta de Cliente · RACHI</title>
  <meta name="description" content="Crie a sua conta de cliente no ecossistema RACHI para aceder ao portal, solicitar propostas, acompanhar pedidos, aceder à Academy e gerir serviços corporativos.">
  <link rel="icon" type="image/svg+xml" href="/favicon.svg">
  <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
  <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
  <link rel="shortcut icon" href="/favicon.ico">
  <link rel="manifest" href="/site.webmanifest">
  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  
  <link rel="stylesheet" href="/toast.css">
  <script src="/toast.js"></script>
  <script src="/auth-session.js"></script>

  <!-- Script Anti-Flash de Tema -->
  <script>
    (function() {
      var t = localStorage.getItem('rachi_theme');
      if (t === 'light') {
        document.documentElement.classList.remove('dark');
        document.documentElement.setAttribute('data-theme', 'light');
      } else {
        document.documentElement.classList.add('dark');
        document.documentElement.setAttribute('data-theme', 'dark');
      }
    })();

    window.toggleRachiTheme = function() {
      var isDark = document.documentElement.classList.toggle('dark');
      var t = isDark ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', t);
      localStorage.setItem('rachi_theme', t);
      var label = document.getElementById('theme-toggle-label');
      if (label) label.textContent = isDark ? 'Modo Claro' : 'Modo Escuro';
      window.dispatchEvent(new CustomEvent('rachi-theme-changed', { detail: { dark: isDark } }));
      return isDark;
    };
  </script>

  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    
    :root {
      --font-sans: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
      --font-heading: 'Outfit', 'Plus Jakarta Sans', sans-serif;
      
      --brand-blue: #0050f0;
      --brand-blue-hover: #0041c4;
      --brand-cyan: #00a3e0;
      --brand-gold: #f5a800;
      
      /* Modo Escuro (Padrão) */
      --bg-page: #060b17;
      --bg-sidebar: #091122;
      --bg-card: rgba(14, 24, 46, 0.95);
      --bg-input: rgba(6, 12, 24, 0.9);
      
      --border-subtle: rgba(255, 255, 255, 0.08);
      --border-card: rgba(255, 255, 255, 0.09);
      --border-hover: rgba(0, 163, 224, 0.4);
      --border-input: rgba(255, 255, 255, 0.14);
      
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --text-dim: #64748b;
      
      --input-focus-border: #00a3e0;
      --input-focus-ring: rgba(0, 163, 224, 0.25);
      
      --badge-admin-bg: rgba(0, 80, 240, 0.15);
      --badge-admin-border: rgba(0, 163, 224, 0.35);
      --badge-admin-text: #38bdf8;
      
      --badge-showcase-bg: rgba(245, 168, 0, 0.12);
      --badge-showcase-border: rgba(245, 168, 0, 0.3);
      --badge-showcase-text: #fbbf24;
      
      --shadow-sidebar: 15px 0 45px rgba(0, 0, 0, 0.35);
      --shadow-card: 0 10px 30px -5px rgba(0, 0, 0, 0.3);
      
      --toggle-bg: rgba(255, 255, 255, 0.06);
      --toggle-border: rgba(255, 255, 255, 0.12);
      --toggle-text: #cbd5e1;
    }

    html:not(.dark) {
      /* Modo Claro */
      --bg-page: #f4f6fa;
      --bg-sidebar: #ffffff;
      --bg-card: #ffffff;
      --bg-input: #ffffff;
      
      --border-subtle: #e2e8f0;
      --border-card: #e5e9f2;
      --border-hover: rgba(0, 80, 240, 0.35);
      --border-input: #cbd5e1;
      
      --text-main: #0f172a;
      --text-muted: #475569;
      --text-dim: #64748b;
      
      --input-focus-border: #0050f0;
      --input-focus-ring: rgba(0, 80, 240, 0.18);
      
      --badge-admin-bg: rgba(0, 80, 240, 0.08);
      --badge-admin-border: rgba(0, 80, 240, 0.22);
      --badge-admin-text: #0050f0;
      
      --badge-showcase-bg: rgba(245, 168, 0, 0.1);
      --badge-showcase-border: rgba(245, 168, 0, 0.25);
      --badge-showcase-text: #b45309;
      
      --shadow-sidebar: 10px 0 35px rgba(15, 23, 42, 0.04);
      --shadow-card: 0 4px 20px -2px rgba(15, 23, 42, 0.06), 0 2px 6px -1px rgba(15, 23, 42, 0.03);
      
      --toggle-bg: #f1f5f9;
      --toggle-border: #cbd5e1;
      --toggle-text: #334155;
    }

    body {
      font-family: var(--font-sans);
      background-color: var(--bg-page);
      color: var(--text-main);
      min-height: 100vh;
      line-height: 1.5;
      display: flex;
      flex-direction: column;
      transition: background-color 0.25s ease, color 0.25s ease;
      background-image: 
        radial-gradient(at 0% 0%, rgba(0, 80, 240, 0.12) 0px, transparent 50%),
        radial-gradient(at 100% 100%, rgba(0, 163, 224, 0.09) 0px, transparent 50%);
      background-attachment: fixed;
    }

    .admin-login-layout {
      display: grid;
      grid-template-columns: minmax(420px, 560px) 1fr;
      min-height: 100vh;
      width: 100%;
    }

    .auth-col {
      background-color: var(--bg-sidebar);
      border-right: 1px solid var(--border-subtle);
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      padding: 2.25rem 2.5rem 1.75rem;
      position: relative;
      z-index: 10;
      box-shadow: var(--shadow-sidebar);
      transition: background-color 0.25s ease, border-color 0.25s ease;
      overflow-y: auto;
      max-height: 100vh;
    }

    .auth-header-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 1.5rem;
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 0.45rem;
      font-size: 0.8rem;
      font-weight: 600;
      color: var(--text-muted);
      text-decoration: none;
      padding: 0.4rem 0.65rem;
      border-radius: 8px;
      transition: all 0.2s ease;
    }
    .back-link:hover {
      color: var(--brand-cyan);
      background: rgba(0, 163, 224, 0.08);
    }
    .back-link svg {
      transition: transform 0.2s ease;
    }
    .back-link:hover svg {
      transform: translateX(-3px);
    }

    .theme-toggle-btn {
      background: var(--toggle-bg);
      border: 1px solid var(--toggle-border);
      color: var(--toggle-text);
      padding: 0.45rem 0.85rem;
      border-radius: 10px;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 0.75rem;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.2s ease;
      user-select: none;
    }
    .theme-toggle-btn:hover {
      border-color: var(--brand-cyan);
      color: var(--text-main);
      background: rgba(0, 163, 224, 0.1);
    }

    html:not(.dark) .icon-sun { display: none; }
    html.dark .icon-moon { display: none; }

    .brand-wrap {
      margin-bottom: 1.25rem;
    }
    .brand-logo-img {
      height: 38px;
      width: auto;
      max-width: 190px;
      display: block;
      object-fit: contain;
    }
    html.dark .logo-for-light { display: none !important; }
    html.dark .logo-for-dark { display: block !important; }
    html:not(.dark) .logo-for-light { display: block !important; }
    html:not(.dark) .logo-for-dark { display: none !important; }

    .auth-title {
      font-family: var(--font-heading);
      font-size: 1.75rem;
      font-weight: 800;
      color: var(--text-main);
      letter-spacing: -0.02em;
      line-height: 1.2;
      margin-top: 0.5rem;
      margin-bottom: 0.35rem;
    }
    .auth-desc {
      font-size: 0.85rem;
      color: var(--text-muted);
      line-height: 1.5;
      margin-bottom: 1.5rem;
    }

    .account-type-toggle {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.5rem;
      background: rgba(0, 0, 0, 0.05);
      border: 1px solid var(--border-subtle);
      padding: 0.25rem;
      border-radius: 12px;
      margin-bottom: 1.25rem;
    }
    html.dark .account-type-toggle {
      background: rgba(255, 255, 255, 0.03);
    }
    .type-btn {
      padding: 0.6rem 0.75rem;
      border: none;
      border-radius: 10px;
      font-size: 0.8rem;
      font-weight: 600;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      color: var(--text-muted);
      background: transparent;
      transition: all 0.2s ease;
    }
    .type-btn.active {
      background: var(--brand-blue);
      color: #ffffff;
      box-shadow: 0 4px 12px rgba(0, 80, 240, 0.3);
    }

    .form-grid-2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.85rem;
    }

    .form-group {
      margin-bottom: 1rem;
    }
    .form-label {
      display: block;
      font-size: 0.75rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: var(--text-muted);
      margin-bottom: 0.35rem;
    }
    .input-wrap {
      position: relative;
      display: flex;
      align-items: center;
    }
    .input-icon {
      position: absolute;
      left: 0.85rem;
      width: 16px;
      height: 16px;
      color: var(--text-dim);
      pointer-events: none;
    }
    .form-control {
      width: 100%;
      padding: 0.65rem 0.85rem 0.65rem 2.35rem;
      font-size: 0.85rem;
      font-family: var(--font-sans);
      color: var(--text-main);
      background-color: var(--bg-input);
      border: 1px solid var(--border-input);
      border-radius: 10px;
      outline: none;
      transition: all 0.2s ease;
    }
    .form-control:focus {
      border-color: var(--input-focus-border);
      box-shadow: 0 0 0 3px var(--input-focus-ring);
    }
    .form-control::placeholder {
      color: var(--text-dim);
    }
    select.form-control {
      padding-left: 0.85rem;
      cursor: pointer;
    }

    .terms-box {
      margin: 1.2rem 0;
      font-size: 0.78rem;
      color: var(--text-muted);
      display: flex;
      align-items: flex-start;
      gap: 0.6rem;
      line-height: 1.45;
    }
    .terms-box input[type="checkbox"] {
      margin-top: 0.2rem;
      accent-color: var(--brand-blue);
      cursor: pointer;
    }
    .terms-box a {
      color: var(--brand-cyan);
      text-decoration: underline;
    }

    .btn-submit {
      width: 100%;
      padding: 0.85rem 1.25rem;
      font-family: var(--font-sans);
      font-size: 0.9rem;
      font-weight: 700;
      color: #ffffff;
      background: linear-gradient(135deg, var(--brand-blue) 0%, #0077e6 100%);
      border: none;
      border-radius: 11px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.6rem;
      transition: all 0.2s ease;
      box-shadow: 0 4px 16px rgba(0, 80, 240, 0.35);
    }
    .btn-submit:hover:not(:disabled) {
      background: linear-gradient(135deg, var(--brand-blue-hover) 0%, #0066cc 100%);
      transform: translateY(-1px);
      box-shadow: 0 6px 20px rgba(0, 80, 240, 0.45);
    }

    .feedback-msg {
      margin-top: 1rem;
      padding: 0.75rem 1rem;
      border-radius: 10px;
      font-size: 0.82rem;
      line-height: 1.4;
    }
    .feedback-msg.error {
      background: rgba(239, 68, 68, 0.12);
      border: 1px solid rgba(239, 68, 68, 0.35);
      color: #f87171;
    }
    .feedback-msg.success {
      background: rgba(16, 185, 129, 0.12);
      border: 1px solid rgba(16, 185, 129, 0.35);
      color: #34d399;
    }

    .auth-footer {
      margin-top: 1.75rem;
      padding-top: 1rem;
      border-top: 1px solid var(--border-subtle);
      font-size: 0.78rem;
      color: var(--text-dim);
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .auth-footer a {
      color: var(--brand-cyan);
      text-decoration: none;
      font-weight: 600;
    }

    /* COLUNA DIREITA: APRESENTAÇÃO */
    .showcase-col {
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding: 3.5rem 4.5rem;
      position: relative;
      overflow-y: auto;
    }
    .showcase-header {
      max-width: 680px;
      margin-bottom: 2rem;
    }
    .showcase-tag {
      display: inline-flex;
      align-items: center;
      gap: 0.45rem;
      padding: 0.35rem 0.85rem;
      border-radius: 9999px;
      font-size: 0.7rem;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      background: var(--badge-showcase-bg);
      color: var(--badge-showcase-text);
      border: 1px solid var(--badge-showcase-border);
      margin-bottom: 1rem;
    }
    .showcase-heading {
      font-family: var(--font-heading);
      font-size: clamp(1.85rem, 2.4vw, 2.4rem);
      font-weight: 800;
      line-height: 1.2;
      color: var(--text-main);
      letter-spacing: -0.02em;
      margin-bottom: 0.85rem;
    }
    .showcase-heading span {
      background: linear-gradient(135deg, var(--brand-cyan) 0%, #60a5fa 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .benefits-list {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 1.25rem;
      max-width: 800px;
      margin-top: 1.5rem;
    }
    .benefit-card {
      background: var(--bg-card);
      border: 1px solid var(--border-card);
      border-radius: 14px;
      padding: 1.25rem;
    }
    .benefit-card h4 {
      font-size: 0.95rem;
      font-weight: 700;
      color: var(--text-main);
      margin-bottom: 0.35rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    .benefit-card p {
      font-size: 0.8rem;
      color: var(--text-muted);
      line-height: 1.45;
    }

    @media (max-width: 1024px) {
      .admin-login-layout {
        grid-template-columns: 1fr;
      }
      .auth-col {
        border-right: none;
        border-bottom: 1px solid var(--border-subtle);
        padding: 2rem 1.5rem;
        max-height: none;
      }
      .showcase-col {
        padding: 2.5rem 1.5rem;
      }
      .benefits-list {
        grid-template-columns: 1fr;
      }
      .form-grid-2 {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

  <div class="admin-login-layout">
    
    <!-- COLUNA ESQUERDA: FORMULÁRIO DE REGISTO DE CLIENTE -->
    <aside class="auth-col">
      <div>
        <div class="auth-header-bar">
          <a href="/" class="back-link" title="Voltar à página inicial">
            <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
            <span>Voltar ao site</span>
          </a>

          <button type="button" class="theme-toggle-btn" onclick="toggleRachiTheme()" aria-label="Alternar tema de cores">
            <svg class="icon-sun" width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
            <svg class="icon-moon" width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>
            <span id="theme-toggle-label">Tema</span>
          </button>
        </div>

        <!-- Marca -->
        <div class="brand-wrap">
          <img src="/images/logo-rachi-dark.png" onerror="this.onerror=null; this.src='/images/logo-rachi.png'" alt="RACHI" class="brand-logo-img logo-for-light">
          <img src="/images/logo-rachi-light.png" onerror="this.onerror=null; this.src='/images/logo-rachi.png'" alt="RACHI" class="brand-logo-img logo-for-dark">
        </div>

        <h1 class="auth-title">Criar Conta de Cliente</h1>
        <p class="auth-desc">Crie a sua conta para acompanhar orçamentos, facturas pró-forma, formações na Academy e chamados de suporte.</p>

        @if ($errors->any())
          <div class="feedback-msg error" style="display:block; margin-bottom: 1.25rem;">
            <strong>Por favor, corrija os seguintes erros:</strong>
            <ul style="margin-top: 0.4rem; padding-left: 1.2rem;">
              @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
              @endforeach
            </ul>
          </div>
        @endif

        <!-- FORMULÁRIO DE REGISTO -->
        <form id="customer-register-form" method="POST" action="/registro">
          @csrf
          
          <!-- Seleção do tipo de cliente -->
          <div class="account-type-toggle">
            <button type="button" class="type-btn active" id="btn-type-ind" onclick="setAccountType('individual')">
              <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
              <span>Particular</span>
            </button>
            <button type="button" class="type-btn" id="btn-type-comp" onclick="setAccountType('company')">
              <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
              <span>Empresa</span>
            </button>
          </div>
          <input type="hidden" name="type" id="input-account-type" value="{{ old('type', 'individual') }}">

          <!-- Nome / Empresa -->
          <div class="form-group">
            <label for="reg-name" class="form-label" id="label-name">Nome Completo</label>
            <div class="input-wrap">
              <svg class="input-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
              <input type="text" id="reg-name" name="name" class="form-control" value="{{ old('name') }}" required placeholder="Ex.: Manuel António dos Santos">
            </div>
          </div>

          <!-- Empresa & NIF -->
          <div class="form-grid-2">
            <div class="form-group" id="group-company-name" style="display: none;">
              <label for="reg-company" class="form-label">Razão Social / Denominação</label>
              <div class="input-wrap">
                <svg class="input-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16"/></svg>
                <input type="text" id="reg-company" name="company_name" class="form-control" value="{{ old('company_name') }}" placeholder="Empresa, Lda.">
              </div>
            </div>

            <div class="form-group">
              <label for="reg-document" class="form-label">NIF (Opcional)</label>
              <div class="input-wrap">
                <svg class="input-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                <input type="text" id="reg-document" name="document" class="form-control" value="{{ old('document') }}" placeholder="Número Fiscal">
              </div>
            </div>
          </div>

          <!-- E-mail & Telefone -->
          <div class="form-grid-2">
            <div class="form-group">
              <label for="reg-email" class="form-label">E-mail</label>
              <div class="input-wrap">
                <svg class="input-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207"/></svg>
                <input type="email" id="reg-email" name="email" class="form-control" value="{{ old('email') }}" required placeholder="contacto@empresa.ao">
              </div>
            </div>

            <div class="form-group">
              <label for="reg-phone" class="form-label">Telefone / WhatsApp</label>
              <div class="input-wrap">
                <svg class="input-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                <input type="text" id="reg-phone" name="phone" class="form-control" value="{{ old('phone') }}" placeholder="+244 923 000 000">
              </div>
            </div>
          </div>

          <!-- Palavra-passe & Confirmação -->
          <div class="form-grid-2">
            <div class="form-group">
              <label for="reg-password" class="form-label">Palavra-passe</label>
              <div class="input-wrap">
                <svg class="input-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                <input type="password" id="reg-password" name="password" class="form-control" required minlength="6" placeholder="Mínimo 6 caracteres">
              </div>
            </div>

            <div class="form-group">
              <label for="reg-password-confirm" class="form-label">Confirmar Palavra-passe</label>
              <div class="input-wrap">
                <svg class="input-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
                <input type="password" id="reg-password-confirm" name="password_confirmation" class="form-control" required minlength="6" placeholder="Repita a palavra-passe">
              </div>
            </div>
          </div>

          <!-- Termos & Privacidade (Conformidade Lei 22/11 de Angola) -->
          <label class="terms-box">
            <input type="checkbox" name="terms_accepted" required id="chk-terms" checked>
            <span>
              Declaro que li e concordo com os <a href="/termos" target="_blank">Termos de Uso</a> e a <a href="/privacidade" target="_blank">Política de Privacidade</a> da RACHI, nos termos da Lei de Protecção de Dados Pessoais de Angola (Lei n.º 22/11).
            </span>
          </label>

          <button type="submit" id="btn-register-submit" class="btn-submit">
            <span>Criar Conta e Aceder ao Portal</span>
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
          </button>
        </form>
      </div>

      <!-- Rodapé -->
      <footer class="auth-footer">
        <span>Já possui uma conta registada?</span>
        <a href="/login">Iniciar Sessão &rarr;</a>
      </footer>
    </aside>

    <!-- COLUNA DIREITA: APRESENTAÇÃO DOS BENEFÍCIOS DO CLIENTE RACHI -->
    <main class="showcase-col">
      <div class="showcase-header">
        <span class="showcase-tag">Ecossistema Integrado de Serviços</span>
        <h2 class="showcase-heading">Uma única conta, <span>todas as soluções</span> do seu negócio.</h2>
        <p style="color: var(--text-muted); font-size: 0.95rem; line-height: 1.6;">
          Ao registar a sua conta no portal da RACHI, a sua empresa passa a contar com um canal direto de atendimento, gestão documental, cotações e acompanhamento contínuo em Luanda e em todo o território nacional.
        </p>
      </div>

      <div class="benefits-list">
        <div class="benefit-card">
          <h4>
            <svg width="18" height="18" fill="none" stroke="#00a3e0" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            RACHI Tec
          </h4>
          <p>Acompanhe chamados de suporte técnico de TI com SLA garantido, cotações de computadores corporativos e projetos de websites.</p>
        </div>

        <div class="benefit-card">
          <h4>
            <svg width="18" height="18" fill="none" stroke="#f5a800" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
            RACHI Print
          </h4>
          <p>Solicite e aprove provas de impressão gráfica, orçamentos de brindes promocionais e sinalética corporativa com facturação formal.</p>
        </div>

        <div class="benefit-card">
          <h4>
            <svg width="18" height="18" fill="none" stroke="#10b981" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z"/></svg>
            RACHI Academy
          </h4>
          <p>Aceda a formações executivas, consulte o estado da matrícula da sua equipa e emita certificados verificáveis via QR Code.</p>
        </div>

        <div class="benefit-card">
          <h4>
            <svg width="18" height="18" fill="none" stroke="#a855f7" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
            RACHI Human Capital
          </h4>
          <p>Consultoria em recursos humanos, recrutamento, processamento salarial, contabilidade e formalização societária.</p>
        </div>
      </div>
    </main>

  </div>

  <script>
    function setAccountType(type) {
      document.getElementById('input-account-type').value = type;
      var btnInd = document.getElementById('btn-type-ind');
      var btnComp = document.getElementById('btn-type-comp');
      var compGroup = document.getElementById('group-company-name');
      var labelName = document.getElementById('label-name');

      if (type === 'company') {
        btnComp.classList.add('active');
        btnInd.classList.remove('active');
        compGroup.style.display = 'block';
        labelName.textContent = 'Nome do Representante / Responsável';
      } else {
        btnInd.classList.add('active');
        btnComp.classList.remove('active');
        compGroup.style.display = 'none';
        labelName.textContent = 'Nome Completo';
      }
    }

    // Inicializar conforme valor anterior (se houver)
    var currentType = "{{ old('type', 'individual') }}";
    if (currentType === 'company') {
      setAccountType('company');
    }
  </script>

</body>
</html>
