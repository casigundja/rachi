<!DOCTYPE html>
<html lang="pt-AO" data-theme="dark" class="scroll-smooth">

<head>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="/toast.css">
    <script src="/toast.js"></script>
    <script src="/auth-session.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Planos RACHI Academy: matricule-se nos melhores cursos de tecnologia, IA e negócios em Angola</title>
    <meta name="description"
        content="Planos RACHI Academy com acesso a cursos práticos de tecnologia, IA, programação, dados, cibersegurança e liderança. Certificação reconhecida, mentorias e projetos reais.">
    <link rel="canonical" href="https://rachi.ao/academy">

    <!-- Open Graph / Redes Sociais -->
    <meta property="og:title" content="Planos RACHI Academy: matricule-se nos melhores cursos de tecnologia e IA">
    <meta property="og:description"
        content="Aprenda com prática, projetos reais e certificação profissional na maior academia tecnológica e executiva de Angola.">
    <meta property="og:url" content="https://rachi.ao/academy">
    <meta property="og:site_name" content="RACHI Academy">
    <meta property="og:locale" content="pt_AO">
    <meta property="og:image" content="/images/areas/rachi-academy.png">
    <meta property="og:type" content="website">

    <link rel="icon" type="image/svg+xml" href="/favicon.svg">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="shortcut icon" href="/favicon.ico">
    <link rel="manifest" href="/site.webmanifest">

    <!-- Google Fonts: Encode Sans, Inter, Montserrat & Roboto Flex -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Encode+Sans:wght@300;400;500;600;700;800;900&family=Inter:wght@300;400;500;600;700;800&family=Montserrat:wght@400;500;600;700;800;900&family=Roboto+Flex:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">

    <!-- Bootstrap 5.3 CSS & JS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        a {
            text-decoration: none !important;
        }

        .alert {
            border-radius: 0.75rem !important;
        }

        .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%);
        }
    
        /* RACHI Cascading 3-Column Dropdown Styles */
        .rachi-cascade-container {
            width: 960px !important;
            max-width: 96vw !important;
            height: 390px !important;
            display: flex;
            flex-direction: row;
            background-color: #ffffff !important;
            box-shadow: 0 25px 60px -15px rgba(0, 15, 40, 0.3) !important;
            border: 1px solid #cbd5e1 !important;
        }
        .rachi-cascade-container[style*="display: none"] {
            display: none !important;
        }
        .dark .rachi-cascade-container {
            background-color: #0e182b !important;
            border: 1px solid rgba(255, 255, 255, 0.12) !important;
            box-shadow: 0 30px 80px -15px rgba(0, 0, 0, 0.95) !important;
        }

        .rachi-cascade-col1 {
            width: 210px !important;
            flex-shrink: 0 !important;
            background-color: #2b303c !important;
            color: #cbd5e1 !important;
            border-right: 1px solid rgba(255, 255, 255, 0.08) !important;
        }
        .dark .rachi-cascade-col1 {
            background-color: #070d19 !important;
        }

        .rachi-cascade-col2 {
            width: 270px !important;
            flex-shrink: 0 !important;
            background-color: #e8ebf0 !important;
            color: #1e293b !important;
            border-right: 1px solid #cbd5e1 !important;
        }
        .dark .rachi-cascade-col2 {
            background-color: #0b1424 !important;
            color: #e2e8f0 !important;
            border-right: 1px solid rgba(255, 255, 255, 0.08) !important;
        }

        .rachi-cascade-col3 {
            flex: 1 1 0% !important;
            background-color: #ffffff !important;
            overflow-y: auto !important;
        }
        .dark .rachi-cascade-col3 {
            background-color: #0e182b !important;
        }

        .rachi-tab-btn-active {
            background-color: #e8ebf0 !important;
            color: #0f172a !important;
            font-weight: 700 !important;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1) !important;
        }
        .dark .rachi-tab-btn-active {
            background-color: #0b1424 !important;
            color: #ffffff !important;
        }

        .rachi-tab-btn-inactive {
            color: #cbd5e1 !important;
        }
        .rachi-tab-btn-inactive:hover {
            color: #ffffff !important;
            background-color: rgba(255, 255, 255, 0.06) !important;
        }

        .rachi-pill-active {
            background-color: #ffffff !important;
            color: #0f172a !important;
            font-weight: 700 !important;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12) !important;
        }
        .dark .rachi-pill-active {
            background-color: #0e182b !important;
            color: #ffffff !important;
            box-shadow: 0 1px 4px rgba(0, 0, 0, 0.4) !important;
        }

    </style>

    <!-- Tailwind CSS CDN -->
    <link rel="stylesheet" href="/worker-marketing.css?v=20261030-2">
    <!-- Alpine.js -->
    <script defer src="/libs/alpine.js"></script>
    <!-- Lucide Icons -->
    <script src="/libs/lucide.js"></script>

    
    <!-- Script de Inicialização Imediata do Tema (Anti-Flash Dark Mode) -->
    <script>
        (function() {
            var theme = localStorage.getItem('rachi_theme');
            if (theme === 'dark' || (!theme && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
        })();

        window.toggleRachiTheme = function() {
            var isDark = document.documentElement.classList.toggle('dark');
            localStorage.setItem('rachi_theme', isDark ? 'dark' : 'light');
            window.dispatchEvent(new CustomEvent('rachi-theme-changed', { detail: { dark: isDark } }));
            return isDark;
        };

        window.addEventListener('storage', function(e) {
            if (e.key === 'rachi_theme') {
                if (e.newValue === 'dark') {
                    document.documentElement.classList.add('dark');
                } else {
                    document.documentElement.classList.remove('dark');
                }
                window.dispatchEvent(new CustomEvent('rachi-theme-changed', { detail: { dark: e.newValue === 'dark' } }));
            }
        });
    </script>
    <link rel="stylesheet" href="/css/site.css?v=1790340043">
    <style>
        [x-cloak] {
            display: none !important;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8fafc;
            color: #0f172a;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        html.dark body {
            background-color: #070f1e;
            color: #ffffff;
        }

        .font-heading {
            font-family: 'Encode Sans', sans-serif;
        }

        /* Glow effects inspirados no design da Alura */
        .glow-cyan {
            box-shadow: 0 0 40px -10px rgba(0, 163, 224, 0.4);
        }

        .glow-blue {
            box-shadow: 0 0 50px -10px rgba(5, 47, 211, 0.5);
        }

        .card-plan {
            transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .card-plan:hover {
            transform: translateY(-6px);
        }

        .no-scrollbar::-webkit-scrollbar {
            display: none !important;
        }
        .no-scrollbar {
            -ms-overflow-style: none !important;
            scrollbar-width: none !important;
        }

        /* ============================================================== */
        /* HEADER DUAL-THEME STYLES (COR E COMPORTAMENTO DO PORTAL)       */
        /* ============================================================== */
        .site-header {
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            right: 0 !important;
            z-index: 1030 !important;
            width: 100% !important;
            background: rgba(7, 19, 38, 0.94) !important;
            backdrop-filter: blur(20px) saturate(180%) !important;
            -webkit-backdrop-filter: blur(20px) saturate(180%) !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.45), inset 0 1px 0 rgba(255, 255, 255, 0.08) !important;
            transition: all 0.3s ease !important;
        }

        .brand-logo-img {
            height: 38px;
            width: auto;
            max-width: 180px;
            object-fit: contain;
            transition: transform 0.25s ease, filter 0.25s ease;
        }

        @media (min-width: 992px) {
            .brand-logo-img {
                height: 40px;
                max-width: 200px;
            }
        }

        /* CAPSULA CENTRAL COESA */
        .site-header .main-nav-capsule {
            display: flex;
            align-items: center;
            gap: 0.15rem;
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 9999px;
            padding: 0.25rem 0.35rem;
            box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.2), 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .site-header .main-nav-capsule .nav-link {
            position: relative;
            font-size: 0.82rem;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.75) !important;
            padding: 0.4rem 0.8rem !important;
            border-radius: 9999px;
            white-space: nowrap;
            text-decoration: none;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            letter-spacing: 0.01em;
        }

        .site-header .main-nav-capsule .nav-link:hover {
            color: #ffffff !important;
            background: rgba(255, 255, 255, 0.08);
        }

        .site-header .main-nav-capsule .nav-link.active {
            color: #ffffff !important;
            background: linear-gradient(135deg, rgba(0, 163, 224, 0.28), rgba(0, 163, 224, 0.14));
            border: 1px solid rgba(0, 163, 224, 0.45);
            box-shadow: 0 0 14px rgba(0, 163, 224, 0.25);
            font-weight: 600;
            padding: 0.4rem 0.95rem !important;
        }

        /* BOTAO DE PERFIL REFINADO & PROXIMO */
        .profile-action-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            border: 1px solid rgba(0, 163, 224, 0.4);
            background: rgba(255, 255, 255, 0.04);
            color: #ffffff;
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            cursor: pointer;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            text-decoration: none;
        }

        .profile-action-btn:hover {
            border-color: #00a3e0;
            background: rgba(0, 163, 224, 0.12);
            transform: translateY(-1px);
            box-shadow: 0 4px 18px rgba(0, 163, 224, 0.35);
        }

        .mobile-menu-btn {
            background: rgba(255, 255, 255, 0.06) !important;
            border: 1px solid rgba(255, 255, 255, 0.1) !important;
            color: #ffffff !important;
        }

        /* PROFILE ICON BUTTON (Ícone de Perfil) */
        .profile-icon-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 38px;
            height: 38px;
            border-radius: 50%;
            border: 1px solid rgba(0, 163, 224, 0.45);
            background: linear-gradient(135deg, rgba(0, 163, 224, 0.18) 0%, rgba(5, 25, 55, 0.5) 100%);
            color: #00a3e0;
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
            cursor: pointer;
            box-shadow: 0 2px 10px rgba(0, 163, 224, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.15);
        }

        .profile-icon-btn:hover {
            border-color: #00a3e0;
            background: linear-gradient(135deg, #00a3e0 0%, #0077c2 100%);
            color: #ffffff;
            transform: translateY(-1px) scale(1.05);
            box-shadow: 0 4px 18px rgba(0, 163, 224, 0.45);
        }
    </style>

    <script>
        window.rachiCascadingMenu = function() {
            return {
                activeTab: 'senioridade',
                activeSeniority: 'iniciante',
                activeArea: 'tech',
                activeCarreira: 'ciber_sec',
                seniorityDetails: {
                    iniciante: {
                        title: 'Iniciante',
                        desc: 'Comece do zero com uma trilha clara e progressiva. Fundamentos práticos para dar os primeiros passos com segurança e construir uma base sólida.'
                    },
                    intermediario: {
                        title: 'Intermediário / Profissional',
                        desc: 'Aprofunde competências práticas, domine ferramentas corporativas de ponta e reduza retrabalho com processos automatizados.'
                    },
                    avancado: {
                        title: 'Executivo & Liderança',
                        desc: 'Estratégia, governança, tomada de decisão e liderança de equipas de alto rendimento para executivos e decisores empresariais.'
                    }
                },
                setTab(tab) {
                    this.activeTab = tab;
                }
            };
        };
    </script>

</head>

<body class="bg-slate-50 text-slate-900 dark:bg-[#070f1e] dark:text-white selection:bg-[#00a3e0] selection:text-white transition-colors duration-300" x-data="rachiAcademyPlans()">

    <!-- ============================================================== -->
    <!-- 1. NAVBAR SUPERIOR OFICIAL (EXATA DO MODELO DO PRINT DA ALURA) -->
    <!-- ============================================================== -->
    <header id="main-site-header"
        class="relative w-full bg-white dark:bg-[#071326] border-b border-slate-200/90 dark:border-white/10 px-3 sm:px-6 lg:px-8 py-2.5 sm:py-3.5 sticky top-0 z-50 backdrop-blur-2xl transition-all duration-300 shadow-[0_4px_25px_rgba(15,23,42,0.09),0_1px_4px_rgba(15,23,42,0.06)] dark:shadow-[0_4px_30px_rgba(0,0,0,0.45)]">
        <div class="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-4">

            <!-- Logo Oficial & Voltar para Início -->
            <div class="flex items-center gap-2 sm:gap-4 shrink-0">
                <a href="/" class="flex items-center justify-center w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-white/5 dark:hover:bg-white/10 text-slate-500 dark:text-slate-400 hover:text-[#0050f0] dark:hover:text-[#00a3e0] transition-colors group" title="Voltar para a página inicial">
                    <i data-lucide="arrow-left" class="w-4 h-4 group-hover:-translate-x-0.5 transition-transform"></i>
                    <span class="sr-only">Voltar para Início</span>
                </a>
                <span class="h-5 w-px bg-slate-200 dark:bg-white/10 hidden sm:block"></span>
                <a href="/"
                    class="flex items-center gap-2 sm:gap-2.5 group cursor-pointer transition-transform duration-200 hover:scale-[1.02] select-none"
                    title="Ir para a página inicial (Portal RACHI)">
                    <picture class="flex items-center shrink-0">
                        <source srcset="/images/areas/rachi-academy.webp" type="image/webp">
                        <img src="/images/areas/rachi-academy.png" 
                             onerror="this.onerror=null; this.src='/images/areas/rachi-academy.png'" 
                             alt="RACHI Academy" 
                             class="h-7 sm:h-9 w-auto object-contain transition-transform duration-200 group-hover:scale-105 filter drop-shadow-[0_2px_8px_rgba(0,80,240,0.35)]">
                    </picture>
                </a>
            </div>

            @php
                $catalogCourses = (isset($courses) && $courses->count() > 0)
                    ? $courses
                    : \App\Models\Course::where('status', 'published')->with('category')->get();
            @endphp
            <!-- Menu Central Cápsula Escura Premium -->
            <nav
                class="hidden lg:flex items-center justify-center bg-slate-100 dark:bg-white/[0.08] border border-slate-200/90 dark:border-white/15 rounded-full p-1 shadow-xs dark:shadow-md shadow-slate-950/20 gap-0.5 text-[13px] tracking-tight transition-all">
                <a href="#home" class="px-4 py-1.5 rounded-full bg-white dark:bg-white/15 text-[#0050f0] dark:text-white font-bold transition-all shadow-xs border border-slate-200/60 dark:border-transparent">Home</a>

                <a href="#cursos" class="px-3.5 py-1.5 rounded-full text-slate-700 dark:text-slate-300 hover:text-[#0050f0] dark:hover:text-white hover:bg-white/60 dark:hover:bg-white/10 font-semibold transition-all">Curso Especializado</a>
                <a href="#modalidades" class="px-3.5 py-1.5 rounded-full text-slate-700 dark:text-slate-300 hover:text-[#0050f0] dark:hover:text-white hover:bg-white/60 dark:hover:bg-white/10 font-semibold transition-all">Modalidades &amp; Preços</a>
                <a href="#contactos" class="px-3.5 py-1.5 rounded-full text-slate-700 dark:text-slate-300 hover:text-[#0050f0] dark:hover:text-white hover:bg-white/60 dark:hover:bg-white/10 font-semibold transition-all">Contactos</a>
            </nav>

            <!-- Botões da Direita -->
            <div class="flex items-center gap-1.5 sm:gap-3 shrink-0">
                <!-- Botão Portal do Aluno -->
                <a href="/academy/login" class="px-2.5 sm:px-4 py-1.5 sm:py-2 rounded-xl text-xs font-bold bg-[#0050f0]/10 dark:bg-[#00a3e0]/10 hover:bg-[#0050f0]/20 text-[#0050f0] dark:text-[#00a3e0] border border-[#0050f0]/20 dark:border-[#00a3e0]/30 transition inline-flex items-center gap-1.5 shadow-sm whitespace-nowrap">
                    <i data-lucide="user" class="w-3.5 h-3.5"></i>
                    <span class="hidden sm:inline">Portal do Aluno</span>
                    <span class="sm:hidden">Portal</span>
                </a>

                <!-- Botão Busca Circular -->
                <a href="#cursos"
                    class="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-slate-100 hover:bg-slate-200/80 dark:bg-white/[0.05] dark:hover:bg-white/[0.12] text-slate-700 hover:text-slate-950 dark:text-slate-300 dark:hover:text-white flex items-center justify-center transition-all duration-200 border border-slate-200/80 hover:border-[#0050f0]/40 dark:border-white/[0.12] dark:hover:border-[#00a3e0]/40 shadow-sm"
                    title="Buscar Cursos">
                    <svg class="w-3.5 h-3.5 sm:w-4 sm:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </a>

                <!-- Botão Menu Mobile -->
                <button @click="mobileMenuOpen = !mobileMenuOpen"
                    class="lg:hidden w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-slate-100 hover:bg-slate-200/80 dark:bg-white/[0.05] dark:hover:bg-white/[0.12] text-slate-700 dark:text-white flex items-center justify-center transition border border-slate-200/80 dark:border-white/[0.12] cursor-pointer"
                    aria-label="Abrir Menu">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
            </div>

        </div>

        <!-- Menu Mobile Dropdown (Mesmo comportamento padronizado das outras páginas, sobrepondo sem empurrar) -->
        <div x-show="mobileMenuOpen" 
             x-transition:enter="transition ease-out duration-200"
             x-transition:enter-start="opacity-0 -translate-y-2 scale-98"
             x-transition:enter-end="opacity-100 translate-y-0 scale-100"
             x-transition:leave="transition ease-in duration-150"
             x-transition:leave-start="opacity-100 translate-y-0 scale-100"
             x-transition:leave-end="opacity-0 -translate-y-2 scale-98"
             @click.away="mobileMenuOpen = false" 
             x-cloak
             class="header-dropdown lg:hidden absolute top-full left-3 right-3 sm:left-6 sm:right-6 mt-1.5 p-5 bg-white/98 dark:bg-[#071326]/98 backdrop-blur-2xl rounded-2xl border border-slate-200/90 dark:border-white/15 space-y-3 text-sm shadow-2xl transition-all z-50 text-slate-800 dark:text-white">
            
            <a href="/" class="block font-medium py-1 text-slate-800 dark:text-white hover:text-[#0050f0] dark:hover:text-[#00a3e0] transition-colors">Home (Portal RACHI)</a>

            <div class="border-t border-slate-200 dark:border-white/10 pt-2">
                <span class="text-xs uppercase font-bold text-[#0050f0] dark:text-[#00a3e0] tracking-wider">Soluções</span>
                <div class="pl-3 mt-1.5 space-y-1.5">
                    <a href="/capital" class="block text-sm text-slate-600 dark:text-slate-400 hover:text-emerald-500 transition-colors">RACHI Human Capital</a>
                    <a href="/academy" class="block text-sm text-[#0050f0] dark:text-[#00a3e0] font-bold">RACHI Academy</a>
                    <a href="/tec" class="block text-sm text-slate-600 dark:text-slate-400 hover:text-sky-500 transition-colors">RACHI Tec</a>
                    <a href="/print" class="block text-sm text-slate-600 dark:text-slate-400 hover:text-amber-500 transition-colors">RACHI Print</a>
                </div>
            </div>

            <div class="border-t border-slate-200 dark:border-white/10 pt-2">
                <span class="text-xs uppercase font-bold text-slate-400 dark:text-slate-500 tracking-wider">RACHI Academy</span>
                <div class="pl-3 mt-1.5 space-y-1.5">
                    <a href="#cursos" @click="mobileMenuOpen = false" class="block text-sm text-slate-600 dark:text-slate-300 hover:text-[#0050f0] dark:hover:text-white transition-colors">Curso Especializado</a>
                    <a href="#modalidades" @click="mobileMenuOpen = false" class="block text-sm text-slate-600 dark:text-slate-300 hover:text-[#0050f0] dark:hover:text-white transition-colors">Modalidades &amp; Preços</a>
                    <a href="#contactos" @click="mobileMenuOpen = false" class="block text-sm text-slate-600 dark:text-slate-300 hover:text-[#0050f0] dark:hover:text-white transition-colors">Contactos</a>
                </div>
            </div>

            <div class="border-t border-slate-200 dark:border-white/10 pt-2.5">
                <template x-if="!isLoggedIn">
                    <a href="/academy/login" class="inline-flex items-center justify-center gap-2 w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#0050f0] to-[#00a3e0] text-white font-bold text-xs shadow-md hover:brightness-110 transition">
                        <i data-lucide="user" class="w-3.5 h-3.5"></i>
                        <span>Entrar no Portal do Aluno</span>
                    </a>
                </template>
                <template x-if="isLoggedIn">
                    <div class="space-y-1.5">
                        <a href="/aluno-dashboard"
                            class="block py-1.5 text-[#0050f0] dark:text-[#00a3e0] font-bold flex items-center justify-between">
                            <span>Meu Dashboard</span>
                            <span class="text-xs bg-[#0050f0]/20 text-[#0050f0] dark:text-[#00a3e0] px-2 py-0.5 rounded"
                                x-text="currentUser ? currentUser.nome.split(' ')[0] : 'Aluno'"></span>
                        </a>
                        <button @click="logout()" class="block w-full text-left py-1 text-rose-500 text-xs cursor-pointer">Sair da Conta</button>
                    </div>
                </template>
            </div>
        </div>
    </header>
    <!-- Header Scroll Script Padronizado -->
    <script>
        (function() {
            function updateHeaderScroll() {
                var header = document.getElementById('main-site-header');
                if (!header) return;
                if (window.scrollY > 20) {
                    header.classList.add('header-scrolled');
                } else {
                    header.classList.remove('header-scrolled');
                }
            }
            window.addEventListener('scroll', updateHeaderScroll, { passive: true });
            updateHeaderScroll();
        })();
    </script>


    <!-- BREADCRUMBS (Padrão Corporativo Unificado RACHI) -->
    <nav class="bg-slate-100/60 dark:bg-[#0c1527]/50 border-b border-slate-200/80 dark:border-white/5 py-3">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ol class="flex items-center flex-wrap gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
                <li><a href="/" class="hover:text-[#0050f0] dark:hover:text-[#00a3e0] transition-colors">Início</a></li>
                <li><i data-lucide="chevron-right" class="w-3 h-3 text-slate-400"></i></li>
                <li class="text-slate-900 dark:text-white font-semibold">RACHI Academy</li>
            </ol>
        </div>
    </nav>

    <!-- ============================================================== -->
    <!-- 2. HERO CAMPAIGN BANNER: CIBERSEGURANÇA (100% FULL BLEED)       -->
    <!-- ============================================================== -->
    <section id="home"
        class="relative w-full overflow-hidden bg-white dark:bg-[#060e1d] min-h-0 lg:min-h-[560px] flex items-stretch transition-colors duration-300 pt-2 pb-14 sm:py-8 lg:py-0">

        <!-- FUNDO AZUL: IMAGEM OFICIAL DAS ONDAS 3D (100% WIDTH COM FUSÃO SUAVE NO DARK MODE) -->
        <div class="absolute inset-0 w-full h-full">
            <img src="/images/set-bg-hero2.png" alt="Fundo Ondas 3D Cibersegurança"
                class="w-full h-full object-cover object-right opacity-95 dark:opacity-85" />
            <!-- Gradiente horizontal suave: garante leitura impecável no texto e fusão perfeita no Dark Mode -->
            <div class="absolute inset-0 bg-gradient-to-b lg:bg-gradient-to-r from-white via-white/95 to-white/70 lg:from-white lg:via-white/90 lg:to-white/40 dark:from-[#060e1d] dark:via-[#060e1d]/90 dark:to-[#060e1d]/60 pointer-events-none"></div>
            <!-- Luzes ambientes e orbes de brilho neon no Dark Mode -->
            <div class="hidden dark:block absolute top-1/4 left-10 w-96 h-96 bg-[#00a3e0]/15 rounded-full blur-[130px] pointer-events-none"></div>
            <div class="hidden dark:block absolute bottom-10 left-1/3 w-80 h-80 bg-[#0050f0]/20 rounded-full blur-[140px] pointer-events-none"></div>
        </div>

        <!-- CURVA ORGÂNICA SVG: ATIVA NO MODO CLARO (Oculta no Dark Mode para fusão contínua sem cortes artificiais) -->
        <div class="hidden lg:block dark:hidden absolute inset-0 w-full h-full pointer-events-none z-10">
            <svg class="w-full h-full" preserveAspectRatio="none" viewBox="0 0 1440 640">
                <path d="M 0,0 
                         L 860,0 
                         C 850,150 915,280 910,380 
                         C 905,480 870,580 840,640 
                         L 0,640 
                         Z" class="fill-white transition-colors duration-300" />
            </svg>
        </div>

        <!-- CONTEÚDO PRINCIPAL EM GRID / FLEX -->
        <div
            class="relative z-20 w-full max-w-[1700px] mx-auto flex flex-col lg:flex-row items-center justify-between min-h-0 lg:min-h-[560px]">

            <!-- COLUNA DA ESQUERDA (CIBERSEGURANÇA DUAL-MODE) -->
            <div
                class="w-full lg:w-[55%] px-5 sm:px-12 lg:pl-16 xl:pl-28 lg:pr-8 pt-6 pb-4 sm:py-8 lg:py-12 text-slate-900 dark:text-white flex flex-col justify-center transition-colors duration-300">

                <!-- Título Oficial Cibersegurança -->
                <h1
                    class="text-2xl sm:text-4xl lg:text-[44px] xl:text-[46px] font-sans font-bold text-slate-900 dark:text-white tracking-tight leading-snug sm:leading-[1.18] mb-3">
                    Seu próximo upgrade pode vir<br class="hidden sm:inline" /> com a Cibersegurança.
                </h1>

                <!-- Subtítulo Oficial -->
                <p class="text-sm sm:text-base text-slate-700 dark:text-slate-300 font-normal leading-relaxed mb-4 max-w-xl">
                    Matricule-se na RACHI Academy com até 40% OFF e domine a segurança de dados e defesa cibernética com instrutores seniores.
                </p>

                <!-- Bullet Points com Marcador Circular Azul com chevron (>) -->
                <div class="space-y-2 mb-6">

                    <div class="flex items-center gap-2.5 text-xs sm:text-sm text-slate-800 dark:text-slate-200 font-medium">
                        <svg class="w-4 h-4 text-[#0050f0] dark:text-[#00a3e0] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                            <circle cx="12" cy="12" r="10" />
                            <path stroke-linecap="round" stroke-linejoin="round" d="M10 8l4 4-4 4" />
                        </svg>
                        <span>Planos a partir de <s class="text-slate-400 dark:text-slate-500">75.000 Kz</s> por 45.000 Kz</span>
                    </div>

                    <div class="flex items-center gap-2.5 text-xs sm:text-sm text-slate-800 dark:text-slate-200 font-medium">
                        <svg class="w-4 h-4 text-[#0050f0] dark:text-[#00a3e0] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                            <circle cx="12" cy="12" r="10" />
                            <path stroke-linecap="round" stroke-linejoin="round" d="M10 8l4 4-4 4" />
                        </svg>
                        <span>7 dias para cancelar com reembolso total garantido</span>
                    </div>

                    <div class="flex items-center gap-2.5 text-xs sm:text-sm text-slate-800 dark:text-slate-200 font-medium">
                        <svg class="w-4 h-4 text-[#0050f0] dark:text-[#00a3e0] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                            <circle cx="12" cy="12" r="10" />
                            <path stroke-linecap="round" stroke-linejoin="round" d="M10 8l4 4-4 4" />
                        </svg>
                        <span>Evolua em tecnologia com profundidade, direção e prática</span>
                    </div>

                </div>

                <!-- Botão CTA Oficial com Gradiente RACHI -->
                <div>
                    <a href="#cursos"
                        class="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3 rounded-xl bg-gradient-to-r from-[#0050f0] via-[#0066ff] to-[#00a3e0] hover:from-[#0042c7] hover:to-[#008ec4] text-white font-extrabold text-sm tracking-wide transition-all duration-300 shadow-lg shadow-[#0050f0]/35 hover:shadow-xl hover:shadow-[#00a3e0]/50 hover:scale-105 active:scale-95 border border-white/20 cursor-pointer group">
                        <svg class="w-4 h-4 text-cyan-200 group-hover:rotate-12 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                        </svg>
                        <span>Aproveitar oferta especial</span>
                        <svg class="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/>
                        </svg>
                    </a>
                </div>

            </div>

            <!-- COLUNA DA DIREITA (ESCUDO 3D DE CIBERSEGURANÇA + MEDALHA) -->
            <div class="w-full lg:w-[45%] relative min-h-0 sm:min-h-[320px] lg:min-h-[560px] flex items-center justify-center pt-4 pb-8 sm:py-6 lg:py-0">

                <div class="relative w-fit mx-auto flex items-center justify-center px-4">
                    <!-- MEDALHA 3D CIRCULAR AZUL: "ATÉ 40% OFF" -->
                    <div class="absolute -top-3 right-0 sm:top-1/2 sm:left-[-40px] sm:-translate-y-1/2 lg:left-[-70px] z-30">
                        <div
                            class="w-20 h-20 sm:w-36 sm:h-36 lg:w-44 lg:h-44 rounded-full bg-gradient-to-b from-[#005bf8] via-[#003db3] to-[#001d68] p-1.5 sm:p-3 shadow-[0_10px_25px_rgba(0,30,100,0.6)] dark:shadow-[0_0_35px_rgba(0,163,224,0.45)] flex items-center justify-center border-2 sm:border-4 border-[#0047d4] dark:border-[#00a3e0] ring-2 ring-[#002277] dark:ring-[#00a3e0]/30 transform hover:scale-105 transition-transform duration-300">
                            <div
                                class="w-full h-full rounded-full border border-sky-400/40 flex flex-col items-center justify-center text-white select-none">
                                <span class="text-[9px] sm:text-sm font-bold tracking-widest uppercase text-sky-100">ATÉ</span>
                                <span
                                    class="text-xl sm:text-4xl lg:text-5xl font-black leading-none tracking-tight text-white my-0.5 drop-shadow-md">40%</span>
                                <span class="text-[9px] sm:text-sm font-black tracking-widest uppercase text-sky-100">OFF</span>
                            </div>
                        </div>
                    </div>

                    <!-- ESCUDO 3D DE DEFESA & SEGURANÇA DIGITAL -->
                    <div class="relative z-20 flex flex-col items-center justify-center pt-2 sm:pt-4 lg:pt-0">
                        <div class="relative group">
                            <img src="/images/cybersecurity-shield-transparent.png"
                                alt="Cibersegurança e Defesa Digital RACHI Academy"
                                class="h-[200px] sm:h-[300px] lg:h-[420px] xl:h-[440px] w-auto max-w-[85vw] object-contain filter drop-shadow-[0_15px_30px_rgba(0,100,240,0.35)] dark:drop-shadow-[0_0_45px_rgba(0,163,224,0.35)] transform group-hover:scale-105 transition-transform duration-500" />
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </section>

    <!-- ============================================================== -->
    <!-- 6. CURSO ESPECIALIZADO: ENGENHARIA SOCIAL INSTITUCIONAL        -->
    <!-- ============================================================== -->
    <section class="py-14 sm:py-20 bg-slate-50/95 dark:bg-[#070f1e] border-t border-slate-200/80 dark:border-white/10 relative overflow-hidden transition-colors duration-300" id="cursos" x-data="{
        modalOpen: false,
        modalidadeSelecionada: 'Workshop Intensivo (60.000 Kz)',
        solicitanteNome: '',
        solicitanteEmpresa: '',
        solicitanteEmail: '',
        solicitanteTelefone: '',
        solicitanteMensagem: '',
        enviarWhatsApp() {
            let msg = `*Solicitação de Inscrição / Proposta — RACHI Academy*%0A%0A` +
                      `*Curso:* Engenharia Social Institucional%0A` +
                      `*Modalidade:* ${this.modalidadeSelecionada}%0A` +
                      `*Nome:* ${this.solicitanteNome || 'Não informado'}%0A` +
                      `*Instituição/Empresa:* ${this.solicitanteEmpresa || 'Não informado'}%0A` +
                      `*Telefone:* ${this.solicitanteTelefone || 'Não informado'}%0A` +
                      `*E-mail:* ${this.solicitanteEmail || 'Não informado'}%0A` +
                      (this.solicitanteMensagem ? `*Observações:* ${this.solicitanteMensagem}%0A` : '');
            window.open(`https://wa.me/972888585?text=${msg}`, '_blank');
        }
    }">
        
        <!-- Luzes ambientes com efeitos glow premium -->
        <div class="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[400px] bg-[#00a3e0]/10 rounded-full blur-[150px] pointer-events-none"></div>
        <div class="absolute bottom-10 right-10 w-72 h-72 bg-[#0050f0]/15 rounded-full blur-[120px] pointer-events-none"></div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-16">
            
            <!-- HEADER DA SEÇÃO: CURSO ESPECIALIZADO -->
            <div class="text-center max-w-4xl mx-auto">
                <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold bg-[#0050f0]/10 dark:bg-[#00a3e0]/15 text-[#0050f0] dark:text-[#00a3e0] border border-[#0050f0]/30 dark:border-[#00a3e0]/30 shadow-xs mb-4">
                    <i data-lucide="shield-check" class="w-4 h-4 text-[#0050f0] dark:text-[#00a3e0]"></i>
                    <span>FORMAÇÃO INSTITUCIONAL EXCLUSIVA &bull; RACHI ACADEMY</span>
                </div>
                <h2 class="text-3xl sm:text-4xl lg:text-5xl font-heading font-black text-slate-900 dark:text-white tracking-tight leading-tight">
                    Curso Especializado: <span class="bg-gradient-to-r from-[#0050f0] via-[#0077ff] to-[#00a3e0] bg-clip-text text-transparent">Engenharia Social Institucional</span>
                </h2>
                <p class="mt-4 text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-3xl mx-auto font-normal">
                    Capacite colaboradores e decisores estratégicos a blindar o elo humano contra manipulações psicológicas, invasões e fraudes direcionadas no contexto corporativo angolano.
                </p>
            </div>

            <!-- BLOCO PRINCIPAL: OBJETIVO + IMAGEM DE ALTO IMPACTO -->
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
                <!-- COLUNA DO OBJETIVO & DESTAQUES (7 cols) -->
                <div class="lg:col-span-7 flex flex-col justify-between bg-white dark:bg-[#071326] border border-slate-200/90 dark:border-white/10 rounded-3xl p-6 sm:p-8 lg:p-10 shadow-xl shadow-slate-900/5 dark:shadow-[0_20px_50px_rgba(0,0,0,0.4)] relative overflow-hidden group">
                    <div class="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-[#0050f0] via-[#00a3e0] to-[#0050f0]"></div>
                    
                    <div>
                        <div class="flex items-center gap-3 mb-4">
                            <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#0050f0] to-[#00a3e0] flex items-center justify-center text-white shadow-md shadow-[#0050f0]/25">
                                <i data-lucide="target" class="w-6 h-6"></i>
                            </div>
                            <div>
                                <span class="text-xs uppercase font-extrabold tracking-widest text-[#0050f0] dark:text-[#00a3e0] block">Finalidade Estratégica</span>
                                <h3 class="text-2xl font-black font-heading text-slate-900 dark:text-white tracking-tight">
                                    Objetivo
                                </h3>
                            </div>
                        </div>

                        <!-- TEXTO OFICIAL DO OBJETIVO -->
                        <div class="p-5 sm:p-6 rounded-2xl bg-slate-50 dark:bg-white/[0.03] border border-slate-200/70 dark:border-white/10 my-4">
                            <p class="text-base sm:text-lg font-medium text-slate-800 dark:text-slate-100 leading-relaxed italic">
                                "Capacitar colaboradores e gestores a reconhecer e neutralizar ataques de engenharia social no ambiente institucional, fortalecendo a cultura de segurança organizacional."
                            </p>
                        </div>

                        <!-- BADGES COM PILARES -->
                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3.5 pt-2">
                            <div class="p-3.5 rounded-xl bg-slate-100/80 dark:bg-white/[0.02] border border-slate-200/80 dark:border-white/5 flex items-start gap-3">
                                <i data-lucide="shield-alert" class="w-5 h-5 text-[#0050f0] dark:text-[#00a3e0] shrink-0 mt-0.5"></i>
                                <div>
                                    <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Human Firewall</h4>
                                    <p class="text-xs text-slate-600 dark:text-slate-400 mt-0.5">Defesa do elo humano contra fraudes</p>
                                </div>
                            </div>

                            <div class="p-3.5 rounded-xl bg-slate-100/80 dark:bg-white/[0.02] border border-slate-200/80 dark:border-white/5 flex items-start gap-3">
                                <i data-lucide="zap" class="w-5 h-5 text-amber-500 shrink-0 mt-0.5"></i>
                                <div>
                                    <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Simulações Reais</h4>
                                    <p class="text-xs text-slate-600 dark:text-slate-400 mt-0.5">Phishing e roleplays práticos</p>
                                </div>
                            </div>

                            <div class="p-3.5 rounded-xl bg-slate-100/80 dark:bg-white/[0.02] border border-slate-200/80 dark:border-white/5 flex items-start gap-3">
                                <i data-lucide="award" class="w-5 h-5 text-emerald-500 shrink-0 mt-0.5"></i>
                                <div>
                                    <h4 class="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">Certificação</h4>
                                    <p class="text-xs text-slate-600 dark:text-slate-400 mt-0.5">Certificado institucional reconhecido</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- BOTÕES DE AÇÃO RÁPIDA -->
                    <div class="pt-6 sm:pt-8 mt-6 border-t border-slate-100 dark:border-white/10 flex flex-wrap items-center gap-3.5">
                        <button @click="modalOpen = true; modalidadeSelecionada = 'Workshop Intensivo (60.000 Kz)'"
                            class="px-6 py-3 rounded-xl bg-gradient-to-r from-[#0050f0] via-[#0066ff] to-[#00a3e0] hover:from-[#0042c7] hover:to-[#008ec4] text-white font-bold text-xs uppercase tracking-wider transition-all duration-300 shadow-lg shadow-[#0050f0]/25 hover:shadow-xl hover:shadow-[#00a3e0]/40 hover:scale-[1.02] cursor-pointer inline-flex items-center gap-2">
                            <span>Inscrever Participantes</span>
                            <i data-lucide="arrow-right" class="w-4 h-4"></i>
                        </button>

                        <button @click="modalOpen = true; modalidadeSelecionada = 'Formação In-Company Personalizada (Sob consulta)'"
                            class="px-5 py-3 rounded-xl bg-transparent hover:bg-slate-100 dark:hover:bg-white/10 text-slate-800 dark:text-white font-bold text-xs uppercase tracking-wider transition-all border border-slate-300 dark:border-white/20 cursor-pointer inline-flex items-center gap-2">
                            <i data-lucide="building" class="w-4 h-4 text-[#0050f0] dark:text-[#00a3e0]"></i>
                            <span>Solicitar Proposta In Company</span>
                        </button>
                    </div>
                </div>

                <!-- COLUNA DA IMAGEM E SELOS (5 cols) -->
                <div class="lg:col-span-5 relative flex flex-col justify-center rounded-3xl overflow-hidden border border-slate-200/90 dark:border-white/10 shadow-xl group">
                    <img src="/images/courses/engenharia-social.jpg" alt="Curso Especializado: Engenharia Social Institucional RACHI Academy"
                        class="w-full h-full min-h-[380px] lg:min-h-full object-cover object-center group-hover:scale-105 transition-transform duration-700">
                    <div class="absolute inset-0 bg-gradient-to-t from-[#071326] via-[#071326]/40 to-transparent"></div>
                    
                    <div class="absolute bottom-6 left-6 right-6 z-10 space-y-3">
                        <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-[11px] font-bold bg-[#0050f0]/80 backdrop-blur-md text-white border border-white/20">
                            <i data-lucide="lock" class="w-3.5 h-3.5"></i>
                            <span>Ambiente de Simulação Ativa</span>
                        </div>
                        <h4 class="text-xl sm:text-2xl font-bold font-heading text-white tracking-tight leading-snug">
                            Blindagem do Fator Humano contra Ameaças Digitais e Presenciais
                        </h4>
                        <p class="text-xs text-slate-200 font-normal leading-relaxed">
                            Instrutores especialistas em segurança da informação, auditoria e inteligência defensiva corporativa.
                        </p>
                    </div>
                </div>
            </div>

            <!-- SEÇÃO: CONTEÚDOS PROGRAMÁTICOS -->
            <div class="pt-4">
                <div class="text-center max-w-3xl mx-auto mb-10">
                    <span class="text-xs uppercase font-extrabold tracking-widest text-[#0050f0] dark:text-[#00a3e0] block">Ementa Oficial</span>
                    <h3 class="text-2xl sm:text-3xl lg:text-4xl font-heading font-black text-slate-900 dark:text-white tracking-tight mt-1">
                        Conteúdos Programáticos
                    </h3>
                    <p class="text-sm text-slate-600 dark:text-slate-300 mt-2">
                        Estrutura programática rigorosa composta por 5 pilares práticos e vivenciais:
                    </p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                    <!-- Tópico 1 -->
                    <div class="p-6 rounded-2xl bg-white dark:bg-[#071326] border border-slate-200/90 dark:border-white/10 hover:border-[#0050f0]/60 dark:hover:border-[#00a3e0]/60 shadow-sm hover:shadow-lg transition-all duration-300 relative group flex flex-col justify-between">
                        <div>
                            <div class="flex items-center justify-between mb-4">
                                <span class="w-10 h-10 rounded-xl bg-[#0050f0]/10 dark:bg-[#00a3e0]/15 text-[#0050f0] dark:text-[#00a3e0] font-mono font-black text-sm flex items-center justify-center border border-[#0050f0]/20 dark:border-[#00a3e0]/30">01</span>
                                <i data-lucide="book-open" class="w-5 h-5 text-slate-400 group-hover:text-[#0050f0] dark:group-hover:text-[#00a3e0] transition-colors"></i>
                            </div>
                            <h4 class="text-base sm:text-lg font-bold text-slate-900 dark:text-white group-hover:text-[#0050f0] dark:group-hover:text-[#00a3e0] transition-colors mb-2">
                                Introdução à Engenharia Social
                            </h4>
                            <p class="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed font-normal">
                                Conceitos, exemplos reais e mapeamento detalhado dos riscos institucionais e regulamentares que afetam as organizações.
                            </p>
                        </div>
                        <div class="mt-4 pt-3 border-t border-slate-100 dark:border-white/5 text-[11px] font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                            <i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500"></i>
                            <span>Fundamentos &amp; Vetores de Risco</span>
                        </div>
                    </div>

                    <!-- Tópico 2 -->
                    <div class="p-6 rounded-2xl bg-white dark:bg-[#071326] border border-slate-200/90 dark:border-white/10 hover:border-[#0050f0]/60 dark:hover:border-[#00a3e0]/60 shadow-sm hover:shadow-lg transition-all duration-300 relative group flex flex-col justify-between">
                        <div>
                            <div class="flex items-center justify-between mb-4">
                                <span class="w-10 h-10 rounded-xl bg-[#0050f0]/10 dark:bg-[#00a3e0]/15 text-[#0050f0] dark:text-[#00a3e0] font-mono font-black text-sm flex items-center justify-center border border-[#0050f0]/20 dark:border-[#00a3e0]/30">02</span>
                                <i data-lucide="alert-triangle" class="w-5 h-5 text-slate-400 group-hover:text-[#0050f0] dark:group-hover:text-[#00a3e0] transition-colors"></i>
                            </div>
                            <h4 class="text-base sm:text-lg font-bold text-slate-900 dark:text-white group-hover:text-[#0050f0] dark:group-hover:text-[#00a3e0] transition-colors mb-2">
                                Táticas de Manipulação Psicológica
                            </h4>
                            <p class="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed font-normal">
                                Phishing, spear phishing, vishing (ligações falsas), pretexting (pretextos fabricados) e tailgating (acesso físico não autorizado).
                            </p>
                        </div>
                        <div class="mt-4 pt-3 border-t border-slate-100 dark:border-white/5 text-[11px] font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                            <i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500"></i>
                            <span>Mecanismos de Engodo Psicológico</span>
                        </div>
                    </div>

                    <!-- Tópico 3 -->
                    <div class="p-6 rounded-2xl bg-white dark:bg-[#071326] border border-slate-200/90 dark:border-white/10 hover:border-[#0050f0]/60 dark:hover:border-[#00a3e0]/60 shadow-sm hover:shadow-lg transition-all duration-300 relative group flex flex-col justify-between">
                        <div>
                            <div class="flex items-center justify-between mb-4">
                                <span class="w-10 h-10 rounded-xl bg-[#0050f0]/10 dark:bg-[#00a3e0]/15 text-[#0050f0] dark:text-[#00a3e0] font-mono font-black text-sm flex items-center justify-center border border-[#0050f0]/20 dark:border-[#00a3e0]/30">03</span>
                                <i data-lucide="building-2" class="w-5 h-5 text-slate-400 group-hover:text-[#0050f0] dark:group-hover:text-[#00a3e0] transition-colors"></i>
                            </div>
                            <h4 class="text-base sm:text-lg font-bold text-slate-900 dark:text-white group-hover:text-[#0050f0] dark:group-hover:text-[#00a3e0] transition-colors mb-2">
                                Cenários Institucionais
                            </h4>
                            <p class="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed font-normal">
                                Casos reais e lições aprendidas em bancos, empresas privadas e órgãos públicos, dissecando prejuízos operacionais e reputacionais.
                            </p>
                        </div>
                        <div class="mt-4 pt-3 border-t border-slate-100 dark:border-white/5 text-[11px] font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                            <i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500"></i>
                            <span>Estudo de Casos Reais de Impacto</span>
                        </div>
                    </div>

                    <!-- Tópico 4 -->
                    <div class="p-6 rounded-2xl bg-white dark:bg-[#071326] border border-slate-200/90 dark:border-white/10 hover:border-[#0050f0]/60 dark:hover:border-[#00a3e0]/60 shadow-sm hover:shadow-lg transition-all duration-300 relative group flex flex-col justify-between">
                        <div>
                            <div class="flex items-center justify-between mb-4">
                                <span class="w-10 h-10 rounded-xl bg-[#0050f0]/10 dark:bg-[#00a3e0]/15 text-[#0050f0] dark:text-[#00a3e0] font-mono font-black text-sm flex items-center justify-center border border-[#0050f0]/20 dark:border-[#00a3e0]/30">04</span>
                                <i data-lucide="shield-check" class="w-5 h-5 text-slate-400 group-hover:text-[#0050f0] dark:group-hover:text-[#00a3e0] transition-colors"></i>
                            </div>
                            <h4 class="text-base sm:text-lg font-bold text-slate-900 dark:text-white group-hover:text-[#0050f0] dark:group-hover:text-[#00a3e0] transition-colors mb-2">
                                Estratégias de Proteção
                            </h4>
                            <p class="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed font-normal">
                                Criação e reforço de políticas de segurança, autenticação robusta (MFA), gestão de acessos e protocolos formais de validação de pedidos urgentes.
                            </p>
                        </div>
                        <div class="mt-4 pt-3 border-t border-slate-100 dark:border-white/5 text-[11px] font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                            <i data-lucide="check" class="w-3.5 h-3.5 text-emerald-500"></i>
                            <span>Políticas de Segurança &amp; Governança</span>
                        </div>
                    </div>

                    <!-- Tópico 5 -->
                    <div class="p-6 rounded-2xl bg-white dark:bg-[#071326] border border-slate-200/90 dark:border-white/10 hover:border-[#0050f0]/60 dark:hover:border-[#00a3e0]/60 shadow-sm hover:shadow-lg transition-all duration-300 relative group md:col-span-2 lg:col-span-2 flex flex-col justify-between bg-gradient-to-br from-white via-white to-blue-50/40 dark:from-[#071326] dark:via-[#071326] dark:to-[#0050f0]/10">
                        <div>
                            <div class="flex items-center justify-between mb-4">
                                <span class="w-10 h-10 rounded-xl bg-[#0050f0]/10 dark:bg-[#00a3e0]/15 text-[#0050f0] dark:text-[#00a3e0] font-mono font-black text-sm flex items-center justify-center border border-[#0050f0]/20 dark:border-[#00a3e0]/30">05</span>
                                <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 uppercase tracking-wider">Prática Vivencial</span>
                            </div>
                            <h4 class="text-base sm:text-lg font-bold text-slate-900 dark:text-white group-hover:text-[#0050f0] dark:group-hover:text-[#00a3e0] transition-colors mb-2">
                                Simulações Práticas
                            </h4>
                            <p class="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed font-normal">
                                Exercícios práticos de phishing controlado em ambiente seguro e roleplays interativos de interações suspeitas para calibrar o reflexo defensivo da equipa.
                            </p>
                        </div>
                        <div class="mt-4 pt-3 border-t border-slate-100 dark:border-white/5 text-[11px] font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                            <i data-lucide="check-circle-2" class="w-3.5 h-3.5 text-emerald-500"></i>
                            <span>Phishing Controlado &amp; Roleplays de Confronto</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- SEÇÃO: MODALIDADES DA FORMAÇÃO & PREÇOS -->
            <div class="pt-4" id="modalidades">
                <div class="text-center max-w-3xl mx-auto mb-10">
                    <span class="text-xs uppercase font-extrabold tracking-widest text-[#0050f0] dark:text-[#00a3e0] block">Investimento &amp; Formatos</span>
                    <h3 class="text-2xl sm:text-3xl lg:text-4xl font-heading font-black text-slate-900 dark:text-white tracking-tight mt-1">
                        Modalidades da Formação
                    </h3>
                    <p class="text-sm text-slate-600 dark:text-slate-300 mt-2">
                        Escolha a opção ideal para a dinâmica da sua equipa e cronograma da sua instituição:
                    </p>
                </div>

                <!-- CARDS DAS 3 MODALIDADES -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 items-stretch mb-10">
                    
                    <!-- 1. WORKSHOP INTENSIVO -->
                    <div class="rounded-3xl p-6 sm:p-8 bg-white dark:bg-[#071326] border border-slate-200/90 dark:border-white/10 shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col justify-between relative group hover:-translate-y-1">
                        <div>
                            <span class="text-xs uppercase font-extrabold tracking-widest text-slate-500 dark:text-slate-400 block mb-2">Formato Prático</span>
                            <h4 class="text-xl sm:text-2xl font-black font-heading text-slate-900 dark:text-white mb-2">
                                Workshop Intensivo
                            </h4>
                            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 dark:bg-blue-500/10 text-[#0050f0] dark:text-[#00a3e0] mb-4">
                                <i data-lucide="clock" class="w-3.5 h-3.5"></i>
                                <span>1 dia (8 horas)</span>
                            </div>

                            <div class="my-4 pt-4 border-t border-slate-100 dark:border-white/5">
                                <span class="text-xs text-slate-500 dark:text-slate-400 block">Preço (por participante)</span>
                                <div class="flex items-baseline gap-1 mt-1">
                                    <span class="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white font-heading">60.000</span>
                                    <span class="text-base font-bold text-slate-700 dark:text-slate-300">Kz</span>
                                </div>
                            </div>

                            <ul class="space-y-2.5 text-xs sm:text-sm text-slate-600 dark:text-slate-300 pt-2">
                                <li class="flex items-center gap-2">
                                    <i data-lucide="check" class="w-4 h-4 text-emerald-500 shrink-0"></i>
                                    <span>Conscientização tática imediata</span>
                                </li>
                                <li class="flex items-center gap-2">
                                    <i data-lucide="check" class="w-4 h-4 text-emerald-500 shrink-0"></i>
                                    <span>Reconhecimento de golpes e phishing</span>
                                </li>
                                <li class="flex items-center gap-2">
                                    <i data-lucide="check" class="w-4 h-4 text-emerald-500 shrink-0"></i>
                                    <span>Material de consulta executivo</span>
                                </li>
                                <li class="flex items-center gap-2">
                                    <i data-lucide="check" class="w-4 h-4 text-emerald-500 shrink-0"></i>
                                    <span>Certificado de participação individual</span>
                                </li>
                            </ul>
                        </div>

                        <div class="mt-8 pt-4 border-t border-slate-100 dark:border-white/10">
                            <button @click="modalOpen = true; modalidadeSelecionada = 'Workshop Intensivo (60.000 Kz)'"
                                class="w-full py-3 rounded-xl bg-slate-900 hover:bg-[#0050f0] text-white dark:bg-white/10 dark:hover:bg-[#00a3e0] dark:hover:text-slate-950 font-bold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2">
                                <span>Inscrever no Workshop</span>
                                <i data-lucide="arrow-right" class="w-4 h-4"></i>
                            </button>
                        </div>
                    </div>

                    <!-- 2. MINI-CURSO (DESTAQUE) -->
                    <div class="rounded-3xl p-6 sm:p-8 bg-gradient-to-b from-[#0050f0]/5 via-white to-white dark:from-[#0050f0]/15 dark:via-[#071326] dark:to-[#071326] border-2 border-[#0050f0] dark:border-[#00a3e0] shadow-2xl shadow-[#0050f0]/15 dark:shadow-[0_20px_50px_rgba(0,163,224,0.25)] flex flex-col justify-between relative group hover:-translate-y-1 transform scale-100 md:scale-105 z-10">
                        <!-- Selo de destaque -->
                        <div class="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-[#0050f0] to-[#00a3e0] text-white text-[11px] font-extrabold uppercase tracking-widest shadow-md">
                            Mais Completo &amp; Recomendado
                        </div>

                        <div>
                            <span class="text-xs uppercase font-extrabold tracking-widest text-[#0050f0] dark:text-[#00a3e0] block mb-2">Formato Aprofundado</span>
                            <h4 class="text-xl sm:text-2xl font-black font-heading text-slate-900 dark:text-white mb-2">
                                Mini-curso
                            </h4>
                            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-[#0050f0]/15 dark:bg-[#00a3e0]/20 text-[#0050f0] dark:text-[#00a3e0] mb-4">
                                <i data-lucide="clock" class="w-3.5 h-3.5"></i>
                                <span>2 dias (16 horas)</span>
                            </div>

                            <div class="my-4 pt-4 border-t border-slate-100 dark:border-white/5">
                                <span class="text-xs text-slate-500 dark:text-slate-400 block">Preço (por participante)</span>
                                <div class="flex items-baseline gap-1 mt-1">
                                    <span class="text-3xl sm:text-4xl font-black text-[#0050f0] dark:text-[#00a3e0] font-heading">100.000</span>
                                    <span class="text-base font-bold text-slate-700 dark:text-slate-300">Kz</span>
                                </div>
                            </div>

                            <ul class="space-y-2.5 text-xs sm:text-sm text-slate-600 dark:text-slate-300 pt-2">
                                <li class="flex items-center gap-2">
                                    <i data-lucide="check" class="w-4 h-4 text-emerald-500 shrink-0"></i>
                                    <span>Tudo incluído do Workshop Intensivo</span>
                                </li>
                                <li class="flex items-center gap-2">
                                    <i data-lucide="check" class="w-4 h-4 text-emerald-500 shrink-0"></i>
                                    <span>Laboratórios de phishing controlado</span>
                                </li>
                                <li class="flex items-center gap-2">
                                    <i data-lucide="check" class="w-4 h-4 text-emerald-500 shrink-0"></i>
                                    <span>Roleplays vivenciais de interação suspeita</span>
                                </li>
                                <li class="flex items-center gap-2">
                                    <i data-lucide="check" class="w-4 h-4 text-emerald-500 shrink-0"></i>
                                    <span>Certificação oficial em Engenharia Social</span>
                                </li>
                            </ul>
                        </div>

                        <div class="mt-8 pt-4 border-t border-slate-100 dark:border-white/10">
                            <button @click="modalOpen = true; modalidadeSelecionada = 'Mini-curso (100.000 Kz)'"
                                class="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#0050f0] via-[#0066ff] to-[#00a3e0] hover:from-[#0042c7] hover:to-[#008ec4] text-white font-black text-xs uppercase tracking-wider transition-all shadow-md shadow-[#0050f0]/30 hover:scale-[1.02] cursor-pointer flex items-center justify-center gap-2">
                                <span>Inscrever no Mini-curso</span>
                                <i data-lucide="arrow-right" class="w-4 h-4"></i>
                            </button>
                        </div>
                    </div>

                    <!-- 3. FORMAÇÃO IN-COMPANY -->
                    <div class="rounded-3xl p-6 sm:p-8 bg-white dark:bg-[#071326] border border-slate-200/90 dark:border-white/10 shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col justify-between relative group hover:-translate-y-1">
                        <div>
                            <span class="text-xs uppercase font-extrabold tracking-widest text-slate-500 dark:text-slate-400 block mb-2">Solução Corporativa</span>
                            <h4 class="text-xl sm:text-2xl font-black font-heading text-slate-900 dark:text-white mb-2">
                                Formação In-Company
                            </h4>
                            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 mb-4">
                                <i data-lucide="calendar" class="w-3.5 h-3.5"></i>
                                <span>Personalizado</span>
                            </div>

                            <div class="my-4 pt-4 border-t border-slate-100 dark:border-white/5">
                                <span class="text-xs text-slate-500 dark:text-slate-400 block">Preço (por participante / turma)</span>
                                <div class="flex items-baseline gap-1 mt-1">
                                    <span class="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white font-heading">Sob consulta</span>
                                </div>
                            </div>

                            <ul class="space-y-2.5 text-xs sm:text-sm text-slate-600 dark:text-slate-300 pt-2">
                                <li class="flex items-center gap-2">
                                    <i data-lucide="check" class="w-4 h-4 text-emerald-500 shrink-0"></i>
                                    <span>Conteúdo alinhado aos riscos da empresa</span>
                                </li>
                                <li class="flex items-center gap-2">
                                    <i data-lucide="check" class="w-4 h-4 text-emerald-500 shrink-0"></i>
                                    <span>Turmas fechadas presenciais ou online</span>
                                </li>
                                <li class="flex items-center gap-2">
                                    <i data-lucide="check" class="w-4 h-4 text-emerald-500 shrink-0"></i>
                                    <span>Relatório executivo de vulnerabilidades</span>
                                </li>
                                <li class="flex items-center gap-2">
                                    <i data-lucide="check" class="w-4 h-4 text-emerald-500 shrink-0"></i>
                                    <span>Consultoria em políticas de segurança</span>
                                </li>
                            </ul>
                        </div>

                        <div class="mt-8 pt-4 border-t border-slate-100 dark:border-white/10">
                            <button @click="modalOpen = true; modalidadeSelecionada = 'Formação In-Company Personalizada (Sob consulta)'"
                                class="w-full py-3 rounded-xl bg-slate-900 hover:bg-[#0050f0] text-white dark:bg-white/10 dark:hover:bg-[#00a3e0] dark:hover:text-slate-950 font-bold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2">
                                <span>Solicitar Proposta In Company</span>
                                <i data-lucide="arrow-right" class="w-4 h-4"></i>
                            </button>
                        </div>
                    </div>

                </div>
            </div>

            <!-- SEÇÃO: CONTACTOS & PARCEIROS EM SOLUÇÕES INTELIGENTES -->
            <div class="pt-4" id="contactos">
                <div class="rounded-3xl bg-gradient-to-br from-[#071326] via-[#091b38] to-[#040914] border border-white/15 p-8 sm:p-10 lg:p-12 text-white relative overflow-hidden shadow-2xl">
                    <!-- Glow decorativo -->
                    <div class="absolute -right-20 -bottom-20 w-96 h-96 bg-[#00a3e0]/20 rounded-full blur-[100px] pointer-events-none"></div>
                    <div class="absolute -left-20 -top-20 w-80 h-80 bg-[#0050f0]/30 rounded-full blur-[90px] pointer-events-none"></div>

                    <div class="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                        <div class="lg:col-span-7 space-y-4">
                            <span class="px-3.5 py-1 rounded-full text-xs font-extrabold bg-[#00a3e0]/20 text-[#00a3e0] border border-[#00a3e0]/30 inline-block uppercase tracking-wider">
                                Atendimento Corporativo &amp; Inscrições
                            </span>
                            <h3 class="text-2xl sm:text-3xl lg:text-4xl font-heading font-black tracking-tight">
                                Parceiros em Soluções Inteligentes – Rachi-Tec, Lda.
                            </h3>
                            <p class="text-sm sm:text-base text-slate-300 leading-relaxed max-w-xl">
                                Agende a capacitação da sua instituição com a nossa equipa especializada ou tire dúvidas sobre inscrições de turmas e propostas In Company.
                            </p>

                            <!-- DADOS DE CONTACTO DESTACADOS -->
                            <div class="pt-2 flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-8 text-sm sm:text-base">
                                <a href="tel:+972888585" class="inline-flex items-center gap-2.5 font-bold hover:text-[#00a3e0] transition-colors group">
                                    <div class="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-[#00a3e0] group-hover:bg-[#00a3e0] group-hover:text-slate-950 transition-all">
                                        <i data-lucide="phone" class="w-5 h-5"></i>
                                    </div>
                                    <span>+972 888 585</span>
                                </a>

                                <a href="mailto:rachi.tec.su@gmail.com" class="inline-flex items-center gap-2.5 font-bold hover:text-[#00a3e0] transition-colors group">
                                    <div class="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-[#00a3e0] group-hover:bg-[#00a3e0] group-hover:text-slate-950 transition-all">
                                        <i data-lucide="mail" class="w-5 h-5"></i>
                                    </div>
                                    <span>rachi.tec.su@gmail.com</span>
                                </a>
                            </div>
                        </div>

                        <div class="lg:col-span-5 flex flex-col sm:flex-row lg:flex-col gap-3.5 justify-end">
                            <a href="https://wa.me/972888585?text=Ol%C3%A1%2C%20gostaria%20de%20informa%C3%A7%C3%B5es%20sobre%20o%20Curso%20Especializado%3A%20Engenharia%20Social%20Institucional." target="_blank"
                                class="px-6 py-4 rounded-xl bg-[#25D366] hover:bg-[#20ba5a] text-slate-950 font-black text-sm uppercase tracking-wider transition-all duration-300 text-center shadow-lg hover:scale-[1.02] flex items-center justify-center gap-2">
                                <i data-lucide="message-circle" class="w-5 h-5"></i>
                                <span>Falar pelo WhatsApp (+972 888 585)</span>
                            </a>

                            <a href="mailto:rachi.tec.su@gmail.com?subject=Inscri%C3%A7%C3%A3o%20-%20Engenharia%20Social%20Institucional"
                                class="px-6 py-4 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-sm uppercase tracking-wider transition-all duration-300 text-center border border-white/20 hover:scale-[1.02] flex items-center justify-center gap-2">
                                <i data-lucide="send" class="w-5 h-5"></i>
                                <span>Enviar E-mail Corporativo</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- MODAL INTERATIVO DE INSCRIÇÃO / COTAÇÃO (ALPINES.JS) -->
        <div x-show="modalOpen" x-cloak
            class="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4"
            x-transition:enter="transition ease-out duration-300"
            x-transition:enter-start="opacity-0"
            x-transition:enter-end="opacity-100"
            x-transition:leave="transition ease-in duration-200"
            x-transition:leave-start="opacity-100"
            x-transition:leave-end="opacity-0">
            
            <div @click.away="modalOpen = false"
                class="bg-white dark:bg-[#071326] border border-slate-200 dark:border-white/15 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl relative text-left"
                x-transition:enter="transition ease-out duration-300"
                x-transition:enter-start="opacity-0 scale-95"
                x-transition:enter-end="opacity-100 scale-100">
                
                <!-- Botão fechar -->
                <button @click="modalOpen = false" class="absolute top-5 right-5 text-slate-400 hover:text-slate-600 dark:hover:text-white transition">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>

                <div class="mb-5">
                    <span class="text-xs uppercase font-extrabold tracking-widest text-[#0050f0] dark:text-[#00a3e0] block">Inscrição &amp; Proposta</span>
                    <h3 class="text-xl sm:text-2xl font-black font-heading text-slate-900 dark:text-white mt-1">
                        Engenharia Social Institucional
                    </h3>
                    <p class="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-1">
                        Preencha os dados abaixo para receber o contacto da equipa RACHI com todos os detalhes.
                    </p>
                </div>

                <form @submit.prevent="enviarWhatsApp()" class="space-y-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">Modalidade Selecionada</label>
                        <select x-model="modalidadeSelecionada" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-white/15 bg-slate-50 dark:bg-white/[0.05] text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-[#0050f0]">
                            <option value="Workshop Intensivo (60.000 Kz)">Workshop Intensivo — 1 dia (8h) &bull; 60.000 Kz</option>
                            <option value="Mini-curso (100.000 Kz)">Mini-curso — 2 dias (16h) &bull; 100.000 Kz</option>
                            <option value="Formação In-Company Personalizada (Sob consulta)">Formação In-Company — Personalizado &bull; Sob consulta</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">Nome Completo</label>
                        <input type="text" x-model="solicitanteNome" required placeholder="Ex: Dr. Manuel dos Santos" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-white/15 bg-slate-50 dark:bg-white/[0.05] text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-[#0050f0]">
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">Instituição / Empresa</label>
                        <input type="text" x-model="solicitanteEmpresa" required placeholder="Ex: Banco / Seguradora / Ministério / Empresa" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-white/15 bg-slate-50 dark:bg-white/[0.05] text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-[#0050f0]">
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                        <div>
                            <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">Telefone / WhatsApp</label>
                            <input type="tel" x-model="solicitanteTelefone" required placeholder="Ex: +244 9..." class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-white/15 bg-slate-50 dark:bg-white/[0.05] text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-[#0050f0]">
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">E-mail Institucional</label>
                            <input type="email" x-model="solicitanteEmail" required placeholder="Ex: contacto@empresa.ao" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-white/15 bg-slate-50 dark:bg-white/[0.05] text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-[#0050f0]">
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">Observações ou N.º de Participantes</label>
                        <textarea x-model="solicitanteMensagem" rows="2" placeholder="Ex: Estimativa de 15 participantes para formação no próximo mês..." class="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-white/15 bg-slate-50 dark:bg-white/[0.05] text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-[#0050f0]"></textarea>
                    </div>

                    <div class="pt-3 flex items-center justify-end gap-3">
                        <button type="button" @click="modalOpen = false" class="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5 transition">
                            Cancelar
                        </button>
                        <button type="submit" class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#0050f0] to-[#00a3e0] hover:from-[#0042c7] hover:to-[#008ec4] text-white font-bold text-xs uppercase tracking-wider transition-all shadow-md shadow-[#0050f0]/30 cursor-pointer inline-flex items-center gap-2">
                            <span>Confirmar via WhatsApp</span>
                            <i data-lucide="send" class="w-3.5 h-3.5"></i>
                        </button>
                    </div>
                </form>

            </div>
        </div>

    </section>

    <!-- ============================================================== -->
    <!-- 5. HISTÓRIAS REAIS & TESTEMUNHOS DE ALUNOS                     -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- 5. HISTÓRIAS REAIS & TESTEMUNHOS DE ALUNOS (ANIMADO & OTIMIZADO) -->
    <!-- ============================================================== -->
    <section class="py-10 sm:py-14 bg-slate-100/70 dark:bg-[#070f1e] transition-colors duration-300 relative overflow-hidden" 
             id="depoimentos" 
             x-data="{ 
                 activeSlide: 1, 
                 progress: 0,
                 isHovered: false,
                 timer: null,
                 startTimer() { 
                     if (this.timer) clearInterval(this.timer);
                     this.timer = setInterval(() => { 
                         if (!this.isHovered) {
                             this.progress += 2;
                             if (this.progress >= 100) {
                                 this.progress = 0;
                                 this.activeSlide = this.activeSlide === 1 ? 2 : 1;
                             }
                         }
                     }, 140); 
                 }, 
                 goTo(slide) {
                     this.activeSlide = slide;
                     this.progress = 0;
                 },
                 next() {
                     this.activeSlide = this.activeSlide === 1 ? 2 : 1;
                     this.progress = 0;
                 },
                 prev() {
                     this.activeSlide = this.activeSlide === 1 ? 2 : 1;
                     this.progress = 0;
                 }
             }" 
             x-init="startTimer()" 
             @mouseenter="isHovered = true" 
             @mouseleave="isHovered = false">
        
        <!-- Luz ambiente sutil de fundo -->
        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[300px] bg-[#00a3e0]/10 rounded-full blur-[130px] pointer-events-none"></div>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">

            <!-- Cabeçalho Otimizado -->
            <div class="text-center max-w-2xl mx-auto mb-7 sm:mb-9">
                <h2 class="text-2xl sm:text-3xl font-heading font-extrabold text-slate-900 dark:text-white tracking-tight leading-tight">
                    Histórias reais de quem escolheu a tecnologia para evoluir na carreira
                </h2>
                <p class="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-2 max-w-lg mx-auto">
                    Conheça a trajetória de profissionais que transformaram seus resultados e aceleraram o crescimento profissional com a RACHI Academy.
                </p>
            </div>

            <!-- SLIDE 1: 3 Histórias -->
            <div x-show="activeSlide === 1" 
                 x-transition:enter="transition ease-out duration-500" 
                 x-transition:enter-start="opacity-0 translate-y-3 scale-[0.99]" 
                 x-transition:enter-end="opacity-100 translate-y-0 scale-100" 
                 x-transition:leave="transition ease-in duration-300 absolute inset-x-0" 
                 x-transition:leave-start="opacity-100 scale-100" 
                 x-transition:leave-end="opacity-0 scale-[0.99]" 
                 class="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-5 items-stretch">

                <!-- Depoimento 1: Mateus Cassoma -->
                <div class="relative p-5 sm:p-6 rounded-2xl bg-white dark:bg-[#0c1527] border border-slate-200/90 dark:border-white/10 hover:border-[#0050f0]/40 dark:hover:border-[#00a3e0]/50 shadow-sm hover:shadow-xl hover:shadow-[#0050f0]/10 dark:hover:shadow-[0_15px_30px_rgba(0,163,224,0.15)] hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between group overflow-hidden h-full">
                    <div class="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#0050f0] via-[#00a3e0] to-[#0050f0] opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    
                    <!-- Marca d'água decorativa de citação -->
                    <svg class="absolute top-4 right-4 w-7 h-7 text-slate-200/60 dark:text-white/5 pointer-events-none group-hover:text-blue-500/20 dark:group-hover:text-cyan-400/20 transition-colors duration-300" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                    </svg>

                    <div>
                        <!-- Topo com Estrelas -->
                        <div class="flex items-center gap-1 text-amber-400 mb-2.5 sm:mb-3">
                            <span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span>
                        </div>
                        <p class="text-xs sm:text-[13px] text-slate-700 dark:text-slate-300 leading-relaxed italic mb-4 sm:mb-5">
                            "Estava buscando uma transição de carreira para a área de dados. Através da trilha prática e das mentorias da RACHI Academy, consegui em 6 meses uma vaga como Engenheiro de Dados em Luanda."
                        </p>
                    </div>

                    <div class="flex items-center gap-3 pt-3.5 border-t border-slate-100 dark:border-white/5">
                        <div class="w-9 h-9 rounded-full bg-gradient-to-tr from-[#0050f0] to-[#00a3e0] text-white flex items-center justify-center font-bold text-xs shadow-xs ring-2 ring-blue-500/20 shrink-0">
                            MC
                        </div>
                        <div class="min-w-0 flex-1">
                            <h4 class="text-xs font-bold text-slate-900 dark:text-white truncate">Mateus Cassoma</h4>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 truncate">Engenheiro de Dados &bull; Luanda</p>
                        </div>
                    </div>
                </div>

                <!-- Depoimento 2: Renata Miranda -->
                <div class="relative p-5 sm:p-6 rounded-2xl bg-white dark:bg-[#0c1527] border border-slate-200/90 dark:border-white/10 hover:border-[#0050f0]/40 dark:hover:border-[#00a3e0]/50 shadow-sm hover:shadow-xl hover:shadow-[#0050f0]/10 dark:hover:shadow-[0_15px_30px_rgba(0,163,224,0.15)] hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between group overflow-hidden h-full">
                    <div class="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#0050f0] via-[#00a3e0] to-[#0050f0] opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    
                    <!-- Marca d'água decorativa de citação -->
                    <svg class="absolute top-4 right-4 w-7 h-7 text-slate-200/60 dark:text-white/5 pointer-events-none group-hover:text-purple-500/20 dark:group-hover:text-purple-400/20 transition-colors duration-300" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                    </svg>

                    <div>
                        <!-- Topo com Estrelas -->
                        <div class="flex items-center gap-1 text-amber-400 mb-2.5 sm:mb-3">
                            <span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span>
                        </div>
                        <p class="text-xs sm:text-[13px] text-slate-700 dark:text-slate-300 leading-relaxed italic mb-4 sm:mb-5">
                            "A metodologia com projetos reais me deu total segurança para entrevistas internacionais. O Modo Entrevista e o Inglês Técnico foram divisores de água para a minha contratação remota."
                        </p>
                    </div>

                    <div class="flex items-center gap-3 pt-3.5 border-t border-slate-100 dark:border-white/5">
                        <div class="w-9 h-9 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-500 text-white flex items-center justify-center font-bold text-xs shadow-xs ring-2 ring-purple-500/20 shrink-0">
                            RM
                        </div>
                        <div class="min-w-0 flex-1">
                            <h4 class="text-xs font-bold text-slate-900 dark:text-white truncate">Renata Miranda</h4>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 truncate">Dev Full Stack Remota &bull; Luanda</p>
                        </div>
                    </div>
                </div>

                <!-- Depoimento 3: Eduardo Manuel -->
                <div class="relative p-5 sm:p-6 rounded-2xl bg-white dark:bg-[#0c1527] border border-slate-200/90 dark:border-white/10 hover:border-[#0050f0]/40 dark:hover:border-[#00a3e0]/50 shadow-sm hover:shadow-xl hover:shadow-[#0050f0]/10 dark:hover:shadow-[0_15px_30px_rgba(0,163,224,0.15)] hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between group overflow-hidden h-full">
                    <div class="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#0050f0] via-[#00a3e0] to-[#0050f0] opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    
                    <!-- Marca d'água decorativa de citação -->
                    <svg class="absolute top-4 right-4 w-7 h-7 text-slate-200/60 dark:text-white/5 pointer-events-none group-hover:text-emerald-500/20 dark:group-hover:text-emerald-400/20 transition-colors duration-300" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                    </svg>

                    <div>
                        <!-- Topo com Estrelas -->
                        <div class="flex items-center gap-1 text-amber-400 mb-2.5 sm:mb-3">
                            <span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span>
                        </div>
                        <p class="text-xs sm:text-[13px] text-slate-700 dark:text-slate-300 leading-relaxed italic mb-4 sm:mb-5">
                            "Como Tech Lead, precisava capacitar desenvolvedores juniores com agilidade e rigor. O conteúdo corporativo da RACHI reduziu nosso tempo de onboarding pela metade com métricas reais."
                        </p>
                    </div>

                    <div class="flex items-center gap-3 pt-3.5 border-t border-slate-100 dark:border-white/5">
                        <div class="w-9 h-9 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-bold text-xs shadow-xs ring-2 ring-emerald-500/20 shrink-0">
                            EM
                        </div>
                        <div class="min-w-0 flex-1">
                            <h4 class="text-xs font-bold text-slate-900 dark:text-white truncate">Eduardo Manuel</h4>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 truncate">Líder Técnico &bull; Setor Bancário</p>
                        </div>
                    </div>
                </div>

            </div>

            <!-- SLIDE 2: Mais 3 Histórias -->
            <div x-show="activeSlide === 2" x-cloak 
                 x-transition:enter="transition ease-out duration-500" 
                 x-transition:enter-start="opacity-0 translate-y-3 scale-[0.99]" 
                 x-transition:enter-end="opacity-100 translate-y-0 scale-100" 
                 x-transition:leave="transition ease-in duration-300 absolute inset-x-0" 
                 x-transition:leave-start="opacity-100 scale-100" 
                 x-transition:leave-end="opacity-0 scale-[0.99]" 
                 class="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-5 items-stretch">

                <!-- Depoimento 4: Teresa Muondo -->
                <div class="relative p-5 sm:p-6 rounded-2xl bg-white dark:bg-[#0c1527] border border-slate-200/90 dark:border-white/10 hover:border-[#0050f0]/40 dark:hover:border-[#00a3e0]/50 shadow-sm hover:shadow-xl hover:shadow-[#0050f0]/10 dark:hover:shadow-[0_15px_30px_rgba(0,163,224,0.15)] hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between group overflow-hidden h-full">
                    <div class="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#0050f0] via-[#00a3e0] to-[#0050f0] opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    
                    <!-- Marca d'água decorativa de citação -->
                    <svg class="absolute top-4 right-4 w-7 h-7 text-slate-200/60 dark:text-white/5 pointer-events-none group-hover:text-red-500/20 dark:group-hover:text-red-400/20 transition-colors duration-300" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                    </svg>

                    <div>
                        <!-- Topo com Estrelas -->
                        <div class="flex items-center gap-1 text-amber-400 mb-2.5 sm:mb-3">
                            <span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span>
                        </div>
                        <p class="text-xs sm:text-[13px] text-slate-700 dark:text-slate-300 leading-relaxed italic mb-4 sm:mb-5">
                            "A formação prática em defesa cibernética e resposta a incidentes foi determinante para a minha contratação na equipa de segurança da informação de uma das maiores telecom de Angola."
                        </p>
                    </div>

                    <div class="flex items-center gap-3 pt-3.5 border-t border-slate-100 dark:border-white/5">
                        <div class="w-9 h-9 rounded-full bg-gradient-to-tr from-rose-600 to-red-500 text-white flex items-center justify-center font-bold text-xs shadow-xs ring-2 ring-red-500/20 shrink-0">
                            TM
                        </div>
                        <div class="min-w-0 flex-1">
                            <h4 class="text-xs font-bold text-slate-900 dark:text-white truncate">Teresa Muondo</h4>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 truncate">Analista SOC &bull; Talatona</p>
                        </div>
                    </div>
                </div>

                <!-- Depoimento 5: Paulo Damião -->
                <div class="relative p-5 sm:p-6 rounded-2xl bg-white dark:bg-[#0c1527] border border-slate-200/90 dark:border-white/10 hover:border-[#0050f0]/40 dark:hover:border-[#00a3e0]/50 shadow-sm hover:shadow-xl hover:shadow-[#0050f0]/10 dark:hover:shadow-[0_15px_30px_rgba(0,163,224,0.15)] hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between group overflow-hidden h-full">
                    <div class="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#0050f0] via-[#00a3e0] to-[#0050f0] opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    
                    <!-- Marca d'água decorativa de citação -->
                    <svg class="absolute top-4 right-4 w-7 h-7 text-slate-200/60 dark:text-white/5 pointer-events-none group-hover:text-amber-500/20 dark:group-hover:text-amber-400/20 transition-colors duration-300" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                    </svg>

                    <div>
                        <!-- Topo com Estrelas -->
                        <div class="flex items-center gap-1 text-amber-400 mb-2.5 sm:mb-3">
                            <span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span>
                        </div>
                        <p class="text-xs sm:text-[13px] text-slate-700 dark:text-slate-300 leading-relaxed italic mb-4 sm:mb-5">
                            "Automatizar relatórios financeiros com Power BI e IA revolucionou a minha consultoria. Em menos de 3 meses dobrei meus clientes atendidos com dashboards executivos em tempo real."
                        </p>
                    </div>

                    <div class="flex items-center gap-3 pt-3.5 border-t border-slate-100 dark:border-white/5">
                        <div class="w-9 h-9 rounded-full bg-gradient-to-tr from-amber-500 to-orange-500 text-white flex items-center justify-center font-bold text-xs shadow-xs ring-2 ring-amber-500/20 shrink-0">
                            PD
                        </div>
                        <div class="min-w-0 flex-1">
                            <h4 class="text-xs font-bold text-slate-900 dark:text-white truncate">Paulo Damião</h4>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 truncate">Consultor de BI &bull; Luanda</p>
                        </div>
                    </div>
                </div>

                <!-- Depoimento 6: Carla Fernandes -->
                <div class="relative p-5 sm:p-6 rounded-2xl bg-white dark:bg-[#0c1527] border border-slate-200/90 dark:border-white/10 hover:border-[#0050f0]/40 dark:hover:border-[#00a3e0]/50 shadow-sm hover:shadow-xl hover:shadow-[#0050f0]/10 dark:hover:shadow-[0_15px_30px_rgba(0,163,224,0.15)] hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between group overflow-hidden h-full">
                    <div class="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#0050f0] via-[#00a3e0] to-[#0050f0] opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    
                    <!-- Marca d'água decorativa de citação -->
                    <svg class="absolute top-4 right-4 w-7 h-7 text-slate-200/60 dark:text-white/5 pointer-events-none group-hover:text-sky-500/20 dark:group-hover:text-blue-400/20 transition-colors duration-300" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                    </svg>

                    <div>
                        <!-- Topo com Estrelas -->
                        <div class="flex items-center gap-1 text-amber-400 mb-2.5 sm:mb-3">
                            <span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span><span class="text-xs sm:text-sm">★</span>
                        </div>
                        <p class="text-xs sm:text-[13px] text-slate-700 dark:text-slate-300 leading-relaxed italic mb-4 sm:mb-5">
                            "Os módulos de liderança estratégica e gestão ágil de projectos trouxeram um salto imediato na produtividade e no alinhamento das nossas equipas multidisciplinares de operações."
                        </p>
                    </div>

                    <div class="flex items-center gap-3 pt-3.5 border-t border-slate-100 dark:border-white/5">
                        <div class="w-9 h-9 rounded-full bg-gradient-to-tr from-sky-600 to-blue-600 text-white flex items-center justify-center font-bold text-xs shadow-xs ring-2 ring-sky-500/20 shrink-0">
                            CF
                        </div>
                        <div class="min-w-0 flex-1">
                            <h4 class="text-xs font-bold text-slate-900 dark:text-white truncate">Carla Fernandes</h4>
                            <p class="text-[11px] text-slate-500 dark:text-slate-400 truncate">Directora de Operações &bull; Luanda</p>
                        </div>
                    </div>
                </div>

            </div>

            <!-- CONTROLOS DO SLIDER (AUTO-PLAY + BARRA DE PROGRESSO + NAVEGAÇÃO COMPACTA) -->
            <div class="flex flex-col items-center justify-center gap-2.5 mt-6 sm:mt-8">
                <!-- Barra de progresso do auto-play suave -->
                <div class="w-28 h-1 bg-slate-200 dark:bg-white/10 rounded-full overflow-hidden">
                    <div class="h-full bg-gradient-to-r from-[#0050f0] to-[#00a3e0] transition-all duration-150 ease-linear rounded-full" 
                         :style="`width: ${progress}%`"></div>
                </div>

                <div class="flex items-center gap-2.5">
                    <!-- Botão Slide Anterior -->
                    <button type="button" 
                            @click="prev()"
                            class="w-8 h-8 rounded-full bg-white dark:bg-[#0c1527] hover:bg-slate-50 dark:hover:bg-white/10 text-slate-700 dark:text-white flex items-center justify-center shadow-xs border border-slate-200/90 dark:border-white/10 hover:border-[#0050f0]/40 transition-all cursor-pointer group"
                            title="Ver depoimento anterior">
                        <i data-lucide="chevron-left" class="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform"></i>
                    </button>

                    <!-- Pílulas Indicadoras com Animação -->
                    <div class="flex items-center gap-1.5">
                        <button type="button" 
                                @click="goTo(1)"
                                :class="activeSlide === 1 ? 'w-7 bg-[#0050f0] dark:bg-[#00a3e0]' : 'w-2 bg-slate-300 dark:bg-white/20 hover:bg-slate-400'"
                                class="h-1.5 rounded-full transition-all duration-300 cursor-pointer"
                                aria-label="Grupo de histórias 1"></button>
                        <button type="button" 
                                @click="goTo(2)"
                                :class="activeSlide === 2 ? 'w-7 bg-[#0050f0] dark:bg-[#00a3e0]' : 'w-2 bg-slate-300 dark:bg-white/20 hover:bg-slate-400'"
                                class="h-1.5 rounded-full transition-all duration-300 cursor-pointer"
                                aria-label="Grupo de histórias 2"></button>
                    </div>

                    <!-- Botão Próximo Slide -->
                    <button type="button" 
                            @click="next()"
                            class="w-8 h-8 rounded-full bg-white dark:bg-[#0c1527] hover:bg-slate-50 dark:hover:bg-white/10 text-slate-700 dark:text-white flex items-center justify-center shadow-xs border border-slate-200/90 dark:border-white/10 hover:border-[#0050f0]/40 transition-all cursor-pointer group"
                            title="Ver próximo depoimento">
                        <i data-lucide="chevron-right" class="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform"></i>
                    </button>
                </div>
            </div>

        </div>
    </section>

        <!-- ============================================================== -->
    <!-- 7. PERGUNTAS FREQUENTES (FAQ)                                   -->
    <!-- ============================================================== -->
    <section class="py-12 sm:py-14 bg-white dark:bg-[#070f1e] border-t border-slate-200/80 dark:border-white/5 transition-colors duration-300 relative" id="faq" x-data="{ activeFaq: 1 }">
        <div class="max-w-2xl mx-auto px-4 sm:px-6">

            <!-- Cabeçalho Compacto & Otimizado -->
            <div class="text-center mb-6 sm:mb-7">
                <span class="text-[11px] font-bold uppercase tracking-widest text-[#0050f0] dark:text-[#00a3e0] bg-[#0050f0]/10 dark:bg-[#00a3e0]/10 px-3 py-1 rounded-full border border-[#0050f0]/20 dark:border-[#00a3e0]/20 inline-block mb-2">
                    Tire Suas Dúvidas
                </span>
                <h2 class="text-2xl sm:text-3xl font-heading font-extrabold text-slate-900 dark:text-white tracking-tight">
                    Perguntas Frequentes
                </h2>
                <p class="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
                    Tudo sobre matrículas, pagamentos em Angola, certificação e metodologia.
                </p>
            </div>

            <!-- Accordion Compacto com Animação Suave -->
            <div class="space-y-2.5">

                <!-- FAQ 1 -->
                <div class="rounded-xl border transition-all duration-200 overflow-hidden cursor-pointer select-none"
                     :class="activeFaq === 1 
                        ? 'border-[#0050f0] dark:border-[#00a3e0] bg-white dark:bg-[#0c182e] shadow-sm ring-1 ring-[#0050f0]/15 dark:ring-[#00a3e0]/20' 
                        : 'border-slate-200/80 dark:border-white/10 bg-slate-50/70 dark:bg-[#0a1324]/70 hover:border-slate-300 dark:hover:border-white/20 hover:bg-slate-50 dark:hover:bg-[#0c182e]/60'"
                     @click="activeFaq = (activeFaq === 1 ? null : 1)">
                    <div class="py-3.5 px-4 sm:px-5 flex items-center justify-between gap-3">
                        <div class="flex items-center gap-2.5 min-w-0">
                            <span class="text-[11px] font-mono font-bold transition-colors shrink-0"
                                  :class="activeFaq === 1 ? 'text-[#0050f0] dark:text-[#00a3e0]' : 'text-slate-400 dark:text-slate-500'">
                                01
                            </span>
                            <span class="text-xs sm:text-sm font-bold text-slate-900 dark:text-white leading-snug">
                                Para quem é a RACHI Academy?
                            </span>
                        </div>
                        <div class="w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-transform duration-300 ease-out"
                             :class="activeFaq === 1 
                                ? 'rotate-180 bg-[#0050f0]/10 dark:bg-[#00a3e0]/15 text-[#0050f0] dark:text-[#00a3e0]' 
                                : 'bg-slate-200/60 dark:bg-white/5 text-slate-400 dark:text-slate-500'">
                            <i data-lucide="chevron-down" class="w-3.5 h-3.5"></i>
                        </div>
                    </div>
                    <div class="grid transition-all duration-300 ease-in-out"
                         :class="activeFaq === 1 ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'">
                        <div class="overflow-hidden">
                            <div class="px-4 sm:px-5 pb-4 pt-1 text-xs text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-white/5">
                                Para iniciantes e profissionais que desejam ingressar ou evoluir com segurança em Tecnologia e Inteligência Artificial, além de líderes e organizações que precisam dominar ferramentas práticas e valorizadas no mercado de Angola e global.
                            </div>
                        </div>
                    </div>
                </div>

                <!-- FAQ 2 -->
                <div class="rounded-xl border transition-all duration-200 overflow-hidden cursor-pointer select-none"
                     :class="activeFaq === 2 
                        ? 'border-[#0050f0] dark:border-[#00a3e0] bg-white dark:bg-[#0c182e] shadow-sm ring-1 ring-[#0050f0]/15 dark:ring-[#00a3e0]/20' 
                        : 'border-slate-200/80 dark:border-white/10 bg-slate-50/70 dark:bg-[#0a1324]/70 hover:border-slate-300 dark:hover:border-white/20 hover:bg-slate-50 dark:hover:bg-[#0c182e]/60'"
                     @click="activeFaq = (activeFaq === 2 ? null : 2)">
                    <div class="py-3.5 px-4 sm:px-5 flex items-center justify-between gap-3">
                        <div class="flex items-center gap-2.5 min-w-0">
                            <span class="text-[11px] font-mono font-bold transition-colors shrink-0"
                                  :class="activeFaq === 2 ? 'text-[#0050f0] dark:text-[#00a3e0]' : 'text-slate-400 dark:text-slate-500'">
                                02
                            </span>
                            <span class="text-xs sm:text-sm font-bold text-slate-900 dark:text-white leading-snug">
                                Quais são as formas de pagamento em Angola?
                            </span>
                        </div>
                        <div class="w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-transform duration-300 ease-out"
                             :class="activeFaq === 2 
                                ? 'rotate-180 bg-[#0050f0]/10 dark:bg-[#00a3e0]/15 text-[#0050f0] dark:text-[#00a3e0]' 
                                : 'bg-slate-200/60 dark:bg-white/5 text-slate-400 dark:text-slate-500'">
                            <i data-lucide="chevron-down" class="w-3.5 h-3.5"></i>
                        </div>
                    </div>
                    <div class="grid transition-all duration-300 ease-in-out"
                         :class="activeFaq === 2 ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'">
                        <div class="overflow-hidden">
                            <div class="px-4 sm:px-5 pb-4 pt-1 text-xs text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-white/5">
                                Pagamento direto em Kwanzas (AOA) por <strong>Multicaixa Express</strong>, transferência bancária por <strong>IBAN</strong> com factura pró-forma e recibo oficial para pessoas físicas ou empresas, e cartões internacionais (Visa/Mastercard) em até 12x.
                            </div>
                        </div>
                    </div>
                </div>

                <!-- FAQ 3 -->
                <div class="rounded-xl border transition-all duration-200 overflow-hidden cursor-pointer select-none"
                     :class="activeFaq === 3 
                        ? 'border-[#0050f0] dark:border-[#00a3e0] bg-white dark:bg-[#0c182e] shadow-sm ring-1 ring-[#0050f0]/15 dark:ring-[#00a3e0]/20' 
                        : 'border-slate-200/80 dark:border-white/10 bg-slate-50/70 dark:bg-[#0a1324]/70 hover:border-slate-300 dark:hover:border-white/20 hover:bg-slate-50 dark:hover:bg-[#0c182e]/60'"
                     @click="activeFaq = (activeFaq === 3 ? null : 3)">
                    <div class="py-3.5 px-4 sm:px-5 flex items-center justify-between gap-3">
                        <div class="flex items-center gap-2.5 min-w-0">
                            <span class="text-[11px] font-mono font-bold transition-colors shrink-0"
                                  :class="activeFaq === 3 ? 'text-[#0050f0] dark:text-[#00a3e0]' : 'text-slate-400 dark:text-slate-500'">
                                03
                            </span>
                            <span class="text-xs sm:text-sm font-bold text-slate-900 dark:text-white leading-snug">
                                A RACHI Academy tem planos para empresas e equipas?
                            </span>
                        </div>
                        <div class="w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-transform duration-300 ease-out"
                             :class="activeFaq === 3 
                                ? 'rotate-180 bg-[#0050f0]/10 dark:bg-[#00a3e0]/15 text-[#0050f0] dark:text-[#00a3e0]' 
                                : 'bg-slate-200/60 dark:bg-white/5 text-slate-400 dark:text-slate-500'">
                            <i data-lucide="chevron-down" class="w-3.5 h-3.5"></i>
                        </div>
                    </div>
                    <div class="grid transition-all duration-300 ease-in-out"
                         :class="activeFaq === 3 ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'">
                        <div class="overflow-hidden">
                            <div class="px-4 sm:px-5 pb-4 pt-1 text-xs text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-white/5">
                                Sim! Com a solução corporativa da RACHI, oferecemos programas personalizados para empresas com gestão de progresso para o RH e contratação corporativa por factura pró-forma / IBAN.
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </section>

        <!-- ============================================================ -->
    <!-- FOOTER INSTITUCIONAL RACHI ACADEMY                          -->
    <!-- ============================================================ -->
    <footer class="bg-slate-100 dark:bg-[#071326] text-slate-700 dark:text-slate-300 pt-16 pb-8 border-t border-slate-200 dark:border-slate-800 transition-colors duration-300">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
                <div>
                    <!-- Footer Logo Oficial RACHI Academy -->
                    <a href="/academy" class="inline-flex items-center gap-2.5 mb-4 group text-decoration-none">
                        <picture class="flex items-center">
                            <source srcset="/images/areas/rachi-academy.webp" type="image/webp">
                            <img src="/images/areas/rachi-academy.png" 
                                 onerror="this.onerror=null; this.src='/images/areas/rachi-academy.png'" 
                                 alt="RACHI Academy" 
                                 class="h-8 w-auto object-contain filter drop-shadow-[0_0_4px_rgba(99,102,241,0.35)] group-hover:scale-105 transition-all">
                        </picture>
                        <span class="font-display font-bold text-base text-slate-900 dark:text-white">RACHI <span class="text-[#0050f0] dark:text-[#00a3e0]">Academy</span></span>
                    </a>
                    <p class="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                        Formação executiva, tecnologia, inteligência artificial e programas corporativos para profissionais e empresas em Angola.
                    </p>
                </div>
                <div>
                    <h4 class="text-sm font-bold uppercase tracking-wider text-[#0050f0] dark:text-[#00a3e0] mb-3">Soluções RACHI</h4>
                    <ul class="space-y-2 text-xs text-slate-600 dark:text-slate-400">
                        <li><a href="/capital" class="hover:text-emerald-400 transition">RACHI Human Capital</a></li>
                        <li><a href="/academy" class="hover:text-indigo-400 transition text-[#0050f0] dark:text-[#00a3e0] font-bold">RACHI Academy</a></li>
                        <li><a href="/tec" class="hover:text-sky-400 transition">RACHI Tec</a></li>
                        <li><a href="/print" class="hover:text-amber-400 transition">RACHI Print</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-sm font-bold uppercase tracking-wider text-[#0050f0] dark:text-[#00a3e0] mb-3">Navegação</h4>
                    <ul class="space-y-2 text-xs text-slate-600 dark:text-slate-400">
                        <li><a href="/" class="hover:text-slate-900 dark:hover:text-white transition">Portal RACHI</a></li>
                        <li><a href="/academy#cursos" class="hover:text-slate-900 dark:hover:text-white transition">Catálogo de Cursos</a></li>
                        <li><a href="/aluno-dashboard" class="hover:text-slate-900 dark:hover:text-white transition">Área do Aluno</a></li>
                        <li><a href="/contacto" class="hover:text-slate-900 dark:hover:text-white transition">Contacto &amp; Matrículas</a></li>
                        <li><a href="/reclamacoes-e-denuncia" class="hover:text-slate-900 dark:hover:text-white transition">Reclamações e Denúncia</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-sm font-bold uppercase tracking-wider text-[#0050f0] dark:text-[#00a3e0] mb-3">Contacto</h4>
                    <p class="text-xs text-slate-600 dark:text-slate-400">Luanda — Angola</p>
                    <p class="text-xs text-slate-600 dark:text-slate-400 mt-1">Horário: Seg-Sex 08h às 17h</p>
                    <p class="text-xs text-slate-600 dark:text-slate-400 mt-2">Formações presenciais e à distância com certificação oficial.</p>
                </div>
            </div>
            <div class="border-t border-slate-200 dark:border-slate-800/80 pt-6 flex flex-col sm:flex-row justify-between items-center text-xs text-slate-500 dark:text-slate-400 gap-4">
                <div>&copy; {{ date('Y') }} <strong class="text-slate-900 dark:text-white">RACHI Academy</strong>. Todos os direitos reservados.</div>
                <div class="flex gap-3 items-center text-xs">
                        <button type="button" onclick="setRachiLanguage('pt')" data-rachi-lang="pt" class="cursor-pointer font-bold text-amber-500 dark:text-amber-400 hover:opacity-100 transition" title="Português">PT</button>
                        <span class="text-slate-500 opacity-60">|</span>
                        <button type="button" onclick="setRachiLanguage('en')" data-rachi-lang="en" class="cursor-pointer opacity-70 hover:opacity-100 hover:text-amber-500 dark:hover:text-amber-400 transition" title="English">EN</button>
                        <span class="text-slate-500 opacity-60">|</span>
                        <button type="button" onclick="setRachiLanguage('zh-CN')" data-rachi-lang="zh-CN" class="cursor-pointer opacity-70 hover:opacity-100 hover:text-amber-500 dark:hover:text-amber-400 transition" title="中文 (Mandarim)">中文</button>
                    </div>
            </div>
        </div>
    </footer>

    <!-- Lógica Alpine.js & Lucide -->
    <script>
        function rachiAcademyPlans() {
            return {
                billingCycle: 'biennial', // 'annual' ou 'biennial'
                activeFaq: 1,
                mobileMenuOpen: false,
                openCursos: false,
                activeMegaTab: 'carreiras',
                isLoggedIn: false,
                currentUser: null,
                userMenuOpen: false,

                async checkAuth() { this.currentUser = await window.RachiSession.session(); this.isLoggedIn = !!this.currentUser; },

                getUserInitials(name) {
                    if (!name) return 'AL';
                    const parts = name.trim().split(' ');
                    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
                    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
                },

                async logout() { await window.RachiSession.logout(); },

                init() {
                    this.checkAuth();




                    if (window.lucide) {
                        this.$nextTick(() => lucide.createIcons());
                    }
                }
            }
        }

        function rachiCatalogScroller() {
            return {
                isPaused: false,
                activeCategory: 'all',
                scrollInterval: null,
                init() {
                    this.$nextTick(() => {
                        this.startScrolling();
                    });
                },
                startScrolling() {
                    this.stopScrolling();
                    const track = this.$refs.scrollerTrack;
                    if (!track) return;
                    this.scrollInterval = setInterval(() => {
                        if (!this.isPaused && track) {
                            const half = track.scrollWidth / 2;
                            if (half > 0 && track.scrollLeft >= (half - 4)) {
                                track.scrollLeft -= half;
                            } else {
                                track.scrollLeft += 1;
                            }
                        }
                    }, 28);
                },
                stopScrolling() {
                    if (this.scrollInterval) {
                        clearInterval(this.scrollInterval);
                        this.scrollInterval = null;
                    }
                },
                pause() {
                    this.isPaused = true;
                },
                resume() {
                    this.isPaused = false;
                },
                scrollLeftBy(amount) {
                    const track = this.$refs.scrollerTrack;
                    if (track) {
                        track.scrollBy({ left: -amount, behavior: 'smooth' });
                    }
                },
                scrollRightBy(amount) {
                    const track = this.$refs.scrollerTrack;
                    if (track) {
                        track.scrollBy({ left: amount, behavior: 'smooth' });
                    }
                },
                setCategory(cat) {
                    this.activeCategory = cat;
                },
                matchesCategory(catName) {
                    if (this.activeCategory === 'all') return true;
                    if (!catName) return false;
                    const clean = catName.toLowerCase();
                    if (this.activeCategory === 'ti') {
                        return clean.includes('tecnologia') || clean.includes('ti') || clean.includes('ciber') || clean.includes('digital') || clean.includes('automação') || clean.includes('sistemas');
                    }
                    if (this.activeCategory === 'gestao') {
                        return clean.includes('gestão') || clean.includes('liderança') || clean.includes('vendas') || clean.includes('corporativa') || clean.includes('contabilidade') || clean.includes('negócios') || clean.includes('profissional');
                    }
                    return true;
                }
            };
        }

        document.addEventListener('DOMContentLoaded', function () {
            if (typeof lucide !== 'undefined') lucide.createIcons();
        });
    </script>



<script src="/worker-public.js"></script>    @include('components.theme-toggle-fab')
</body>

</html>
